from time import sleep
from requests import Session
from requests.adapters import HTTPAdapter
from urllib3.util import Retry
from azext_xsignextension.Helpers import Helpers


class EsrpGatewayClient(object):
    def __init__(self, gateway_api=None, client_id=None, retries=None, backoff_factor=None, 
        status_forcelist=None, timeout=None):
        self.httpsclient = Session()
        self.retries = Retry(total=20,
                    backoff_factor=10,
                    status_forcelist=[413, 429, 500, 502, 503, 504],
                    allowed_methods= False,
                    )
        self.httpsclient.mount('https://', HTTPAdapter(max_retries=retries))
        self.gateway_api=gateway_api
        self.client_id=client_id


    def create_session(self, bearer_auth, payload):
        url = "{gatewayApi}/api/v2/{clientId}/workflows/session".format(gatewayApi=self.gateway_api, clientId=self.client_id)
        headers = {"Authorization": "Bearer {}".format(bearer_auth), "Content-Type": "application/json"}
        response = self.httpsclient.post(url, data=payload, headers=headers)

        return response


    def submit_to_sign_file(self, request_json, bearer_auth):
        url = "{gatewayApi}/api/v2/{clientId}/workflows/sign".format(gatewayApi=self.gateway_api, clientId=self.client_id)
        response = self.httpsclient.post(url, data=request_json, 
            headers={"Authorization": "Bearer {}".format(bearer_auth), 
                    "Content-type": "application/json"})

        return response


    def query_sign_status(self, operation_id, bearer_auth):
        # Query for sign status
        url_sign_status = "{gatewayApi}/api/v2/{clientId}/workflows/sign/operations/{operationId}".format(
            gatewayApi=self.gateway_api, clientId=self.client_id, operationId=operation_id)
        headers = {"Authorization": "Bearer {}".format(bearer_auth), "Content-Type": "application/json"}

        terminal_conditions = ["pass", "failCanRetry", "failDoNotRetry", "pendingAnalysis"]

        isDone = False
        attempts = 0
        while not isDone:
            attempts+=1
            response = self.httpsclient.get(url_sign_status, headers=headers)
            if any(terminal in response.text for terminal in terminal_conditions):
                isDone = True
            elif "inprogress" in response.text:
                Helpers.print_to_console("Attempt #{attempts}: In Progress...".format(attempts=attempts))
                sleep(2)

        return response