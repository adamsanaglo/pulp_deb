import json
from os import path
from collections import namedtuple

from azext_xsignextension.Helpers import Helpers

class ConfigFile(object):
    def __init__(self, config_file):
        self.config_file = config_file
        self.configProperties = None

    def get_config_properties(self):
        self.parse_config_file()
        return self.configProperties

    def parse_config_file(self):
        if not self.configProperties is None:
            return

        # Parse out configs
        if not path.exists(self.config_file):
            raise FileNotFoundError("\nConfiguration file does not exist: " + self.config_file)

        with open(self.config_file, 'r') as f:
            self.configProperties = json.loads(f.read(), object_hook=lambda d: namedtuple('config', d.keys())(*d.values()))

    # default value of extensionTimeout is 7200
    def get_timeout(self):
        self.parse_config_file()

        if not hasattr(self.configProperties, "extensionTimeoutInSec"):
            return 7200

        return self.configProperties.extensionTimeoutInSec

