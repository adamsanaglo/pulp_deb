import collections
import functools
import json
import threading
import time
import uuid
from enum import Enum
from datetime import timedelta
from typing import Any, Dict, Tuple, List, Optional, TYPE_CHECKING, cast, Union, Iterable, AnyStr
from urllib.parse import urlparse, quote_plus

from azure.core.tracing import AbstractSpan
from uamqp.constants import TransportType
from uamqp import SendClient, AMQPClient, Message, authentication, constants, errors, compat, utils, BatchMessage, types, Connection, TransportType, c_uamqp

from azext_xsignextension.Helpers import Helpers
from azext_xsignextension.eventhub.EventHubHelpers import EventHubHelpers, Constants
from azext_xsignextension.eventhub.EventHubError import _handle_exception, ClientClosedError, ConnectError, EventHubError,  _error_handler, OperationTimeoutError



# event_data.encoded_size < 255, batch encode overhead is 5, >=256, overhead is 8 each
_BATCH_MESSAGE_OVERHEAD_COST = [5, 8]

_SYS_PROP_KEYS_TO_MSG_PROPERTIES = (
    (Constants.PROP_MESSAGE_ID, "message_id"),
    (Constants.PROP_USER_ID, "user_id"),
    (Constants.PROP_TO, "to"),
    (Constants.PROP_SUBJECT, "subject"),
    (Constants.PROP_REPLY_TO, "reply_to"),
    (Constants.PROP_CORRELATION_ID, "correlation_id"),
    (Constants.PROP_CONTENT_TYPE, "content_type"),
    (Constants.PROP_CONTENT_ENCODING, "content_encoding"),
    (Constants.PROP_ABSOLUTE_EXPIRY_TIME, "absolute_expiry_time"),
    (Constants.PROP_CREATION_TIME, "creation_time"),
    (Constants.PROP_GROUP_ID, "group_id"),
    (Constants.PROP_GROUP_SEQUENCE, "group_sequence"),
    (Constants.PROP_REPLY_TO_GROUP_ID, "reply_to_group_id"),
)

_Address = collections.namedtuple("Address", "hostname path")
_AccessToken = collections.namedtuple("AccessToken", "token expires_on")


def _parse_conn_str(conn_str, kwargs):
    endpoint = None
    shared_access_key_name = None
    shared_access_key = None
    entity_path = None  # type: Optional[str]
    eventhub_name = kwargs.pop("eventhub_name", None)  # type: Optional[str]
    for element in conn_str.split(";"):
        key, _, value = element.partition("=")
        if key.lower() == "endpoint":
            endpoint = value.rstrip("/")
        elif key.lower() == "hostname":
            endpoint = value.rstrip("/")
        elif key.lower() == "sharedaccesskeyname":
            shared_access_key_name = value
        elif key.lower() == "sharedaccesskey":
            shared_access_key = value
        elif key.lower() == "entitypath":
            entity_path = value
    if not all([endpoint, shared_access_key_name, shared_access_key]):
        raise ValueError(
            "Invalid connection string. Should be in the format: "
            "Endpoint=sb://<FQDN>/;SharedAccessKeyName=<KeyName>;SharedAccessKey=<KeyValue>"
        )
    entity = cast(str, eventhub_name or entity_path)
    left_slash_pos = cast(str, endpoint).find("//")
    if left_slash_pos != -1:
        host = cast(str, endpoint)[left_slash_pos + 2 :]
    else:
        host = str(endpoint)
    return host, str(shared_access_key_name), str(shared_access_key), entity


def _generate_sas_token(uri, policy, key, expiry=None):
    if not expiry:
        expiry = timedelta(hours=1)  # Default to 1 hour.

    abs_expiry = int(time.time()) + expiry.seconds
    encoded_uri = quote_plus(uri).encode("utf-8")
    encoded_policy = quote_plus(policy).encode("utf-8")
    encoded_key = key.encode("utf-8")

    token = utils.create_sas_token(encoded_policy, encoded_key, encoded_uri, expiry)
    return _AccessToken(token=token, expires_on=abs_expiry)


class Configuration(object):
    def __init__(self, **kwargs):
        self.user_agent = kwargs.get("user_agent")  # type: Optional[str]
        self.retry_total = kwargs.get("retry_total", 3)  # type: int
        self.max_retries = self.retry_total  # type: int
        self.backoff_factor = kwargs.get("retry_backoff_factor", 0.8)  # type: float
        self.backoff_max = kwargs.get("retry_backoff_max", 120)  # type: int
        self.network_tracing = kwargs.get("network_tracing", False)  # type: bool
        self.http_proxy = kwargs.get("http_proxy")  # type: Optional[Dict[str, Any]]
        self.transport_type = (
            TransportType.AmqpOverWebsocket
            if self.http_proxy
            else kwargs.get("transport_type", TransportType.Amqp)
        )
        self.auth_timeout = kwargs.get("auth_timeout", 60)  # type: int
        self.prefetch = kwargs.get("prefetch", 300)  # type: int
        self.max_batch_size = kwargs.get("max_batch_size", self.prefetch)  # type: int
        self.receive_timeout = kwargs.get("receive_timeout", 0)  # type: int
        self.send_timeout = kwargs.get("send_timeout", 60)  # type: int


class EventHubSharedKeyCredential(object):
    def __init__(self, policy, key):
        # type: (str, str) -> None
        self.policy = policy
        self.key = key
        self.token_type = b"servicebus.windows.net:sastoken"

    def get_token(self, *scopes, **kwargs):  # pylint:disable=unused-argument
        # type: (str, Any) -> _AccessToken
        if not scopes:
            raise ValueError("No token scope provided.")
        return _generate_sas_token(scopes[0], self.policy, self.key)


class EventHubProducerClient(object):
    def __init__(self, fully_qualified_namespace, eventhub_name, credential, **kwargs):
        self.eventhub_name = eventhub_name
        if not eventhub_name:
            raise ValueError("The eventhub name can not be None or empty.")
        path = "/" + eventhub_name if eventhub_name else ""
        self._address = _Address(hostname=fully_qualified_namespace, path=path)
        self._container_id = Constants.CONTAINER_PREFIX + str(uuid.uuid4())[:8]
        self._credential = credential
        self._keep_alive = kwargs.get("keep_alive", 30)
        self._auto_reconnect = kwargs.get("auto_reconnect", True)
        self._mgmt_target = "amqps://{}/{}".format(
            self._address.hostname, self.eventhub_name
        )
        self._auth_uri = "sb://{}{}".format(self._address.hostname, self._address.path)
        self._config = Configuration(**kwargs)
        self._debug = self._config.network_tracing
        self._conn_manager = get_connection_manager(**kwargs)
        self._idle_timeout = kwargs.get("idle_timeout", None)
        self._producers = { Constants.ALL_PARTITIONS: self._create_producer() }
        self._max_message_size_on_link = 0
        self._partition_ids = None
        self._lock = threading.Lock()



    @classmethod
    def from_connection_string(cls, conn_str, **kwargs):
        host, policy, key, entity = _parse_conn_str(conn_str, kwargs)
        kwargs["fully_qualified_namespace"] = host
        kwargs["eventhub_name"] = entity
        kwargs["credential"] = EventHubSharedKeyCredential(policy, key)
        return cls(**kwargs)


    def _get_max_mesage_size(self):
        # pylint: disable=protected-access,line-too-long
        with self._lock:
            if not self._max_message_size_on_link:
                cast(EventHubProducer, self._producers[Constants.ALL_PARTITIONS])._open_with_retry()
                self._max_message_size_on_link = (
                    self._producers[Constants.ALL_PARTITIONS]._handler.message_handler._link.peer_max_message_size
                    or constants.MAX_MESSAGE_LENGTH_BYTES)


    def _start_producer(self, partition_id, send_timeout):
        with self._lock:
            if (not self._producers[partition_id] or cast(EventHubProducer, 
                self._producers[partition_id]).closed):
                self._producers[partition_id] = self._create_producer(
                    partition_id=partition_id, send_timeout=send_timeout)


    def _create_producer(self, partition_id=None, send_timeout=None):
        target = "amqps://{}{}".format(self._address.hostname, self._address.path)
        send_timeout = (self._config.send_timeout if send_timeout is None else send_timeout)

        handler = EventHubProducer(self, target, partition=partition_id, 
            send_timeout=send_timeout, idle_timeout=self._idle_timeout,)
        return handler


    def send_batch(self, event_data_batch, **kwargs):
        partition_id = kwargs.get("partition_id")
        partition_key = kwargs.get("partition_key")
        if isinstance(event_data_batch, EventDataBatch):
            if partition_id or partition_key:
                raise TypeError("partition_id and partition_key should be None when sending an EventDataBatch "
                                "because type EventDataBatch itself may have partition_id or partition_key")
            to_send_batch = event_data_batch
        else:
            to_send_batch = self.create_batch(partition_id=partition_id, partition_key=partition_key)
            to_send_batch._load_events(event_data_batch)  # pylint:disable=protected-access
        partition_id = (to_send_batch._partition_id or Constants.ALL_PARTITIONS)  # pylint:disable=protected-access

        send_timeout = kwargs.pop("timeout", None)
        try:
            cast(EventHubProducer, self._producers[partition_id]).send(
                to_send_batch, timeout=send_timeout)
        except (KeyError, AttributeError, EventHubError):
            self._start_producer(partition_id, send_timeout)
            cast(EventHubProducer, self._producers[partition_id]).send(
                to_send_batch, timeout=send_timeout)


    def create_batch(self, **kwargs):
        if not self._max_message_size_on_link:
            self._get_max_mesage_size()

        max_size_in_bytes = kwargs.get("max_size_in_bytes", None)
        partition_id = kwargs.get("partition_id", None)
        partition_key = kwargs.get("partition_key", None)

        if max_size_in_bytes and max_size_in_bytes > self._max_message_size_on_link:
            raise ValueError(
                "Max message size: {} is too large, acceptable max batch size is: {} bytes.".format(
                    max_size_in_bytes, self._max_message_size_on_link)
            )

        event_data_batch = EventDataBatch(
            max_size_in_bytes=(max_size_in_bytes or self._max_message_size_on_link),
            partition_id=partition_id,
            partition_key=partition_key)

        return event_data_batch

    def _backoff(self, retried_times, last_exception, timeout_time=None, entity_name=None):
        entity_name = entity_name or self._container_id
        backoff = self._config.backoff_factor * 2 ** retried_times
        if backoff <= self._config.backoff_max and (
            timeout_time is None or time.time() + backoff <= timeout_time
        ):  # pylint:disable=no-else-return
            time.sleep(backoff)
        else:
            raise last_exception


    def _create_auth(self):
        try:
            token_type = self._credential.token_type    # type: ignore
        except AttributeError:
            token_type = b"jwt"
        if token_type == b"servicebus.windows.net:sastoken":
            auth = authentication.JWTTokenAuth(
                self._auth_uri,
                self._auth_uri,
                functools.partial(self._credential.get_token, self._auth_uri),
                token_type=token_type,
                timeout=self._config.auth_timeout,
                http_proxy=self._config.http_proxy,
                transport_type=self._config.transport_type,
            )
            auth.update_token()
            return auth
        return authentication.JWTTokenAuth(
            self._auth_uri,
            self._auth_uri,
            functools.partial(self._credential.get_token, Constants.JWT_TOKEN_SCOPE),
            token_type=token_type,
            timeout=self._config.auth_timeout,
            http_proxy=self._config.http_proxy,
            transport_type=self._config.transport_type,
        )


    def _close_connection(self):
        self._conn_manager.reset_connection_if_broken()


    def close(self):
        with self._lock:
            for producer in self._producers.values():
                if producer:
                    producer.close()
            self._producers = {}
        self._conn_manager.close_connection()


class EventData(object):
    def __init__(self, body=None):
        self._last_enqueued_event_properties = {}  # type: Dict[str, Any]
        self._sys_properties = None  # type: Optional[Dict[bytes, Any]]
        if body and isinstance(body, list):
            self.message = Message(body[0])
            for more in body[1:]:
                self.message._body.append(more)  # pylint: disable=protected-access
        elif body is None:
            raise ValueError("EventData cannot be None.")
        else:
            self.message = Message(body)
        self.message.annotations = {}
        self.message.application_properties = {}

    def __repr__(self):
        try:
            body_str = self.body_as_str()
        except:
            body_str = "<read-error>"
        event_repr = "body='{}'".format(body_str)
        try:
            event_repr += ", properties={}".format(self.properties)
        except:
            event_repr += ", properties=<read-error>"
        try:
            event_repr += ", offset={}".format(self.offset)
        except:
            event_repr += ", offset=<read-error>"
        try:
            event_repr += ", sequence_number={}".format(self.sequence_number)
        except:
            event_repr += ", sequence_number=<read-error>"
        try:
            event_repr += ", partition_key={!r}".format(self.partition_key)
        except:
            event_repr += ", partition_key=<read-error>"
        try:
            event_repr += ", enqueued_time={!r}".format(self.enqueued_time)
        except:
            event_repr += ", enqueued_time=<read-error>"
        return "EventData({})".format(event_repr)

    def __str__(self):
        try:
            body_str = self.body_as_str()
        except: 
            body_str = "<read-error>"
        event_str = "{{ body: '{}'".format(body_str)
        try:
            event_str += ", properties: {}".format(self.properties)
            if self.offset:
                event_str += ", offset: {}".format(self.offset)
            if self.sequence_number:
                event_str += ", sequence_number: {}".format(self.sequence_number)
            if self.partition_key:
                event_str += ", partition_key={!r}".format(self.partition_key)
            if self.enqueued_time:
                event_str += ", enqueued_time={!r}".format(self.enqueued_time)
        except:  # pylint: disable=bare-except
            pass
        event_str += " }"
        return event_str

    @classmethod
    def _from_message(cls, message):
        event_data = cls(body="")
        event_data.message = message
        return event_data

    def _encode_message(self):
        # type: () -> bytes
        return self.message.encode_message()

    @property
    def sequence_number(self):
        return self.message.annotations.get(Constants.PROP_SEQ_NUMBER, None)

    @property
    def offset(self):
        # type: () -> Optional[str]
        try:
            return self.message.annotations[Constants.PROP_OFFSET].decode("UTF-8")
        except (KeyError, AttributeError):
            return None

    @property
    def enqueued_time(self):
        timestamp = self.message.annotations.get(Constants.PROP_TIMESTAMP, None)
        if timestamp:
            return Helpers.utc_from_timestamp(float(timestamp) / 1000)
        return None

    @property
    def partition_key(self):
        try:
            return self.message.annotations[Constants.PROP_PARTITION_KEY_AMQP_SYMBOL]
        except KeyError:
            return self.message.annotations.get(Constants.PROP_PARTITION_KEY, None)

    @property
    def properties(self):
        return self.message.application_properties

    @properties.setter
    def properties(self, value):
        properties = None if value is None else dict(value)
        self.message.application_properties = properties

    @property
    def system_properties(self):
        # type: () -> Dict[bytes, Any]
        """Metadata set by the Event Hubs Service associated with the event.

        An EventData could have some or all of the following meta data depending on the source
        of the event data.

            - b"x-opt-sequence-number" (int)
            - b"x-opt-offset" (bytes)
            - b"x-opt-partition-key" (bytes)
            - b"x-opt-enqueued-time" (int)
            - b"message-id" (bytes)
            - b"user-id" (bytes)
            - b"to" (bytes)
            - b"subject" (bytes)
            - b"reply-to" (bytes)
            - b"correlation-id" (bytes)
            - b"content-type" (bytes)
            - b"content-encoding" (bytes)
            - b"absolute-expiry-time" (int)
            - b"creation-time" (int)
            - b"group-id" (bytes)
            - b"group-sequence" (bytes)
            - b"reply-to-group-id" (bytes)

        :rtype: dict
        """
        if self._sys_properties is None:
            self._sys_properties = {}
            if self.message.properties:
                for key, prop_name in _SYS_PROP_KEYS_TO_MSG_PROPERTIES:
                    value = getattr(self.message.properties, prop_name, None)
                    if value:
                        self._sys_properties[key] = value
            self._sys_properties.update(self.message.annotations)
        return self._sys_properties

    @property
    def body(self):
        try:
            return self.message.get_data()
        except TypeError:
            raise ValueError("Event content empty.")

    def body_as_str(self, encoding="UTF-8"):
        data = self.body
        try:
            return "".join(b.decode(encoding) for b in cast(Iterable[bytes], data))
        except TypeError:
            return type(data)
        except:  # pylint: disable=bare-except
            pass
        try:
            return cast(bytes, data).decode(encoding)
        except Exception as e:
            raise TypeError(
                "Message data is not compatible with string type: {}".format(e)
            )

    def body_as_json(self, encoding="UTF-8"):
        data_str = self.body_as_str(encoding=encoding)
        try:
            return json.loads(data_str)
        except Exception as e:
            raise TypeError("Event data is not compatible with JSON type: {}".format(e))


class EventDataBatch(object):
    def __init__(self, max_size_in_bytes=None, partition_id=None, partition_key=None):
        self.max_size_in_bytes = max_size_in_bytes or constants.MAX_MESSAGE_LENGTH_BYTES
        self.message = BatchMessage(data=[], multi_messages=False, properties=None)
        self._partition_id = partition_id
        self._partition_key = partition_key

        EventHubHelpers.set_message_partition_key(self.message, self._partition_key)
        self._size = self.message.gather()[0].get_message_encoded_size()
        self._count = 0

    def __repr__(self):
        batch_repr = "max_size_in_bytes={}, partition_id={}, partition_key={!r}, event_count={}".format(
            self.max_size_in_bytes, self._partition_id, self._partition_key, self._count
        )
        return "EventDataBatch({})".format(batch_repr)

    def __len__(self):
        return self._count

    @classmethod
    def _from_batch(cls, batch_data, partition_key=None):
        batch_data_instance = cls(partition_key=partition_key)
        batch_data_instance.message._body_gen = (  # pylint:disable=protected-access
            batch_data
        )
        return batch_data_instance

    def _load_events(self, events):
        for event_data in events:
            try:
                self.add(event_data)
            except ValueError:
                raise ValueError("The combined size of EventData collection exceeds the Event Hub frame size limit. "
                                 "Please send a smaller collection of EventData, or use EventDataBatch, "
                                 "which is guaranteed to be under the frame size limit")

    @property
    def size_in_bytes(self):
        return self._size

    def add(self, event_data):
        if self._partition_key:
            if (
                event_data.partition_key
                and event_data.partition_key != self._partition_key
            ):
                raise ValueError(
                    "The partition key of event_data does not match the partition key of this batch."
                )
            if not event_data.partition_key:
                EventHubHelpers.set_message_partition_key(event_data.message, self._partition_key)

        EventHubHelpers.trace_message(event_data)
        event_data_size = event_data.message.get_message_encoded_size()

        # For a BatchMessage, if the encoded_message_size of event_data is < 256, then the overhead cost to encode that
        # message into the BatchMessage would be 5 bytes, if >= 256, it would be 8 bytes.
        size_after_add = (
            self._size
            + event_data_size
            + _BATCH_MESSAGE_OVERHEAD_COST[0 if (event_data_size < 256) else 1]
        )

        if size_after_add > self.max_size_in_bytes:
            raise ValueError(
                "EventDataBatch has reached its size limit: {}".format(
                    self.max_size_in_bytes
                )
            )

        self.message._body_gen.append(event_data)  # pylint: disable=protected-access
        self._size = size_after_add
        self._count += 1


class ConsumerProducerMixin(object):
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def _create_handler(self, auth):
        pass

    def _check_closed(self):
        if self.closed:
            raise ClientClosedError(
                "{} has been closed. Please create a new one to handle event data.".format(
                    self._name
                )
            )

    def _open(self):
        if not self.running:
            if self._handler:
                self._handler.close()
            auth = self._client._create_auth()
            self._create_handler(auth)
            self._handler.open(
                connection=self._client._conn_manager.get_connection(
                    self._client._address.hostname, auth
                )
            )
            while not self._handler.client_ready():
                time.sleep(0.05)
            self._max_message_size_on_link = (
                self._handler.message_handler._link.peer_max_message_size
                or constants.MAX_MESSAGE_LENGTH_BYTES
            )
            self.running = True

    def _close_handler(self):
        if self._handler:
            self._handler.close()  # close the link (sharing connection) or connection (not sharing)
        self.running = False

    def _close_connection(self):
        self._close_handler()
        self._client._conn_manager.reset_connection_if_broken()

    def _handle_exception(self, exception):
        if not self.running and isinstance(exception, compat.TimeoutException):
            exception = errors.AuthenticationException("Authorization timeout.")

        return _handle_exception(exception, self)


    def _do_retryable_operation(self, operation, timeout=None, **kwargs):
        timeout_time = (time.time() + timeout) if timeout else None
        retried_times = 0
        last_exception = kwargs.pop("last_exception", None)
        operation_need_param = kwargs.pop("operation_need_param", True)
        max_retries = self._client._config.max_retries

        while retried_times <= max_retries:
            try:
                if operation_need_param:
                    return operation(
                        timeout_time=timeout_time,
                        last_exception=last_exception,
                        **kwargs)
                return operation()
            except Exception as exception:
                last_exception = self._handle_exception(exception)
                self._client._backoff(
                    retried_times=retried_times,
                    last_exception=last_exception,
                    timeout_time=timeout_time,
                    entity_name=self._name)
                retried_times += 1
                if retried_times > max_retries:
                    raise last_exception

    def close(self):
        print("close - client base")
        self._close_handler()
        self.closed = True


class EventHubProducer(ConsumerProducerMixin):
    def __init__(self, client, target, **kwargs):
        partition = kwargs.get("partition", None)
        send_timeout = kwargs.get("send_timeout", 60)
        keep_alive = kwargs.get("keep_alive", None)
        auto_reconnect = kwargs.get("auto_reconnect", True)
        idle_timeout = kwargs.get("idle_timeout", None)

        self.running = False
        self.closed = False

        self._max_message_size_on_link = None
        self._client = client
        self._target = target
        self._partition = partition
        self._timeout = send_timeout
        self._idle_timeout = (idle_timeout * 1000) if idle_timeout else None
        self._error = None
        self._keep_alive = keep_alive
        self._auto_reconnect = auto_reconnect
        self._retry_policy = errors.ErrorPolicy(
            max_retries=self._client._config.max_retries, on_error=_error_handler
        )
        self._reconnect_backoff = 1
        self._name = "EHProducer-{}".format(uuid.uuid4())
        self._unsent_events = []
        if partition:
            self._target += "/Partitions/" + partition
            self._name += "-partition{}".format(partition)
        self._handler = None
        self._outcome = None
        self._condition = None
        self._lock = threading.Lock()
        self._link_properties = {
            types.AMQPSymbol(Constants.TIMEOUT_SYMBOL): types.AMQPLong(int(self._timeout * 1000))
        }

    def _create_handler(self, auth):
        self._handler = SendClient(
            self._target,
            auth=auth,
            debug=self._client._config.network_tracing,
            msg_timeout=self._timeout * 1000,
            idle_timeout=self._idle_timeout,
            error_policy=self._retry_policy,
            keep_alive_interval=self._keep_alive,
            client_name=self._name,
            link_properties=self._link_properties,
            properties=EventHubHelpers.create_properties(self._client._config.user_agent)
        )

    def _open_with_retry(self):
        return self._do_retryable_operation(self._open, operation_need_param=False)

    def _set_msg_timeout(self, timeout_time, last_exception):
        if not timeout_time:
            return
        remaining_time = timeout_time - time.time()
        if remaining_time <= 0.0:
            if last_exception:
                error = last_exception
            else:
                error = OperationTimeoutError("Send operation timed out")
            raise error
        self._handler._msg_timeout = remaining_time * 1000


    def _send_event_data(self, timeout_time=None, last_exception=None):
        if self._unsent_events:
            self._open()
            self._set_msg_timeout(timeout_time, last_exception)
            self._handler.queue_message(*self._unsent_events)
            self._handler.wait()
            self._unsent_events = self._handler.pending_messages
            if self._outcome != constants.MessageSendResult.Ok:
                if self._outcome == constants.MessageSendResult.Timeout:
                    self._condition = OperationTimeoutError("Send operation timed out")
                if self._condition:
                    raise self._condition


    def _send_event_data_with_retry(self, timeout=None):
        return self._do_retryable_operation(self._send_event_data, timeout=timeout)


    def _on_outcome(self, outcome, condition):
        self._outcome = outcome
        self._condition = condition


    def _wrap_eventdata(self, event_data, span, partition_key):
        if isinstance(event_data, EventData):
            if partition_key:
                EventHubHelpers.set_message_partition_key(event_data.message, partition_key)
            wrapper_event_data = event_data
            EventHubHelpers.trace_message(wrapper_event_data, span)
            EventHubHelpers.add_link_to_send(wrapper_event_data, span)
        else:
            if isinstance(event_data, EventDataBatch):  # The partition_key in the param will be omitted.
                if (partition_key and partition_key != event_data._partition_key):
                    raise ValueError("The partition_key does not match the one of the EventDataBatch")
                for message in event_data.message._body_gen:
                    EventHubHelpers.add_link_to_send(message, span)
                wrapper_event_data = event_data
            else:
                if partition_key:
                    event_data = self._set_partition_key(event_data, partition_key)
                event_data = self._set_trace_message(event_data, span)
                wrapper_event_data = EventDataBatch._from_batch(event_data, partition_key)
        wrapper_event_data.message.on_send_complete = self._on_outcome
        return wrapper_event_data

    def _set_partition_key(self, event_datas, partition_key):
        for ed in iter(event_datas):
            EventHubHelpers.set_message_partition_key(ed.message, partition_key)
            yield ed


    def _set_trace_message(self, event_datas, parent_span=None):
        for ed in iter(event_datas):
            EventHubHelpers.trace_message(ed, parent_span)
            EventHubHelpers.add_link_to_send(ed, parent_span)
            yield ed


    def send(self, event_data, partition_key=None, timeout=None):
        # Tracing code
        with self._lock:
            with EventHubHelpers.send_context_manager() as child:
                self._check_closed()
                wrapper_event_data = self._wrap_eventdata(event_data, child, partition_key)
                self._unsent_events = [wrapper_event_data.message]

                if child:
                    self._client._add_span_request_attributes(child)

                self._send_event_data_with_retry(timeout=timeout)


    def close(self):
        """
        Close down the handler. If the handler has already closed,
        this will be a no op.
        """
        with self._lock:
            super(EventHubProducer, self).close()


class _ConnectionMode(Enum):
    ShareConnection = 1
    SeparateConnection = 2


class _SharedConnectionManager(object):
    def __init__(self, **kwargs):
        self._lock = threading.Lock()
        self._conn = None
        self._container_id = kwargs.get("container_id")
        self._debug = kwargs.get("debug")
        self._error_policy = kwargs.get("error_policy")
        self._properties = kwargs.get("properties")
        self._encoding = kwargs.get("encoding") or "UTF-8"
        self._transport_type = kwargs.get("transport_type") or TransportType.Amqp
        self._http_proxy = kwargs.get("http_proxy")
        self._max_frame_size = kwargs.get("max_frame_size")
        self._channel_max = kwargs.get("channel_max")
        self._idle_timeout = kwargs.get("idle_timeout")
        self._remote_idle_timeout_empty_frame_send_ratio = kwargs.get(
            "remote_idle_timeout_empty_frame_send_ratio"
        )

    def get_connection(self, host, auth):
        with self._lock:
            if self._conn is None:
                self._conn = Connection(
                    host,
                    auth,
                    container_id=self._container_id,
                    max_frame_size=self._max_frame_size,
                    channel_max=self._channel_max,
                    idle_timeout=self._idle_timeout,
                    properties=self._properties,
                    remote_idle_timeout_empty_frame_send_ratio=self._remote_idle_timeout_empty_frame_send_ratio,
                    error_policy=self._error_policy,
                    debug=self._debug,
                    encoding=self._encoding,
                )
            return self._conn


    def close_connection(self):
        with self._lock:
            if self._conn:
                self._conn.destroy()
            self._conn = None

    def reset_connection_if_broken(self):
        with self._lock:
            if self._conn and self._conn._state in (c_uamqp.ConnectionState.CLOSE_RCVD, c_uamqp.ConnectionState.CLOSE_SENT,
                c_uamqp.ConnectionState.DISCARDING, c_uamqp.ConnectionState.END,):
                self._conn = None


class _SeparateConnectionManager(object):
    def __init__(self, **kwargs):
        pass

    def get_connection(self, host, auth):
        return None

    def close_connection(self):
        pass

    def reset_connection_if_broken(self):
        pass


def get_connection_manager(**kwargs):
    connection_mode = kwargs.get("connection_mode", _ConnectionMode.SeparateConnection)
    if connection_mode == _ConnectionMode.ShareConnection:
        return _SharedConnectionManager(**kwargs)
    return _SeparateConnectionManager(**kwargs)