import calendar
import datetime
import platform
import six
import sys

from azure.core.settings import settings
from azure.core.tracing import SpanKind
from contextlib import contextmanager
from uamqp import types
from uamqp.message import MessageHeader

from azext_xsignextension import Helpers


class EventHubHelpers:
    @staticmethod
    def create_properties(user_agent=None):
        properties = {}
        properties[types.AMQPSymbol("product")] = Constants.USER_AGENT_PREFIX
        framework = "Python/{}.{}.{}".format(
            sys.version_info[0], sys.version_info[1], sys.version_info[2]
        )
        properties[types.AMQPSymbol("framework")] = framework
        platform_str = platform.platform()
        properties[types.AMQPSymbol("platform")] = platform_str

        final_user_agent = "{}/{} {} ({})".format(
            Constants.USER_AGENT_PREFIX, "Test", framework, platform_str
        )
        if user_agent:
            final_user_agent = "{} {}".format(final_user_agent, user_agent)

        if len(final_user_agent) > Constants.MAX_USER_AGENT_LENGTH:
            raise ValueError(
                "The user-agent string cannot be more than {} in length."
                "Current user_agent string is: {} with length: {}".format(
                    Constants.MAX_USER_AGENT_LENGTH, final_user_agent, len(final_user_agent)
                )
            )
        properties[types.AMQPSymbol("user-agent")] = final_user_agent
        return properties


    @staticmethod
    def set_message_partition_key(message, partition_key):
        if partition_key:
            annotations = message.annotations
            if annotations is None:
                annotations = dict()
            annotations[
                Constants.PROP_PARTITION_KEY_AMQP_SYMBOL
            ] = partition_key  # pylint:disable=protected-access
            header = MessageHeader()
            header.durable = True
            message.annotations = annotations
            message.header = header


    @staticmethod
    @contextmanager
    def send_context_manager():
        span_impl_type = (
            settings.tracing_implementation()
        )  # type: Type[AbstractSpan]

        if span_impl_type is not None:
            with span_impl_type(name="Azure.EventHubs.send") as child:
                child.kind = SpanKind.CLIENT
                yield child
        else:
            yield None

    @staticmethod
    def add_link_to_send(event, send_span):
        if send_span and event.properties:
            traceparent = event.properties.get(b"Diagnostic-Id", "").decode("ascii")
            if traceparent:
                send_span.link(traceparent)



    @staticmethod
    def trace_message(event, parent_span=None):
        span_impl_type = settings.tracing_implementation()  # type: Type[AbstractSpan]
        if span_impl_type is not None:
            current_span = parent_span or span_impl_type(
                span_impl_type.get_current_span()
            )
            with current_span.span(name="Azure.EventHubs.message") as message_span:
                message_span.kind = SpanKind.PRODUCER
                message_span.add_attribute("az.namespace", "Microsoft.EventHub")
                if not event.properties:
                    event.properties = dict()
                event.properties.setdefault(
                    b"Diagnostic-Id", message_span.get_trace_parent().encode("ascii")
                )


    @staticmethod
    def trace_link_message(events, parent_span=None):
        trace_events = events if isinstance(events, Iterable) else (events,)
        span_impl_type = settings.tracing_implementation()
        if span_impl_type is not None:
            current_span = parent_span or span_impl_type(
                span_impl_type.get_current_span())
            if current_span:
                for event in trace_events:
                    if event.properties:
                        traceparent = event.properties.get(b"Diagnostic-Id", "").decode("ascii")
                        if traceparent:
                            current_span.link(
                                traceparent,
                                attributes={"enqueuedTime": event.message.annotations.get(Constants.PROP_TIMESTAMP)}
                            )


    @staticmethod
    def event_position_selector(value, inclusive=False):
        operator = ">=" if inclusive else ">"
        if isinstance(value, datetime.datetime):  # pylint:disable=no-else-return
            timestamp = (calendar.timegm(value.utctimetuple()) * 1000) + (
                value.microsecond / 1000
            )
            return (
                "amqp.annotation.x-opt-enqueued-time {} '{}'".format(
                    operator, int(timestamp)
                )
            ).encode("utf-8")
        elif isinstance(value, six.integer_types):
            return (
                "amqp.annotation.x-opt-sequence-number {} '{}'".format(operator, value)
            ).encode("utf-8")
        return ("amqp.annotation.x-opt-offset {} '{}'".format(operator, value)).encode(
            "utf-8"
        )


    @staticmethod
    def get_last_enqueued_event_properties(event_data):
        # pylint: disable=protected-access
        if event_data._last_enqueued_event_properties:
            return event_data._last_enqueued_event_properties

        if event_data.message.delivery_annotations:
            sequence_number = event_data.message.delivery_annotations.get(
                Constants.PROP_LAST_ENQUEUED_SEQUENCE_NUMBER, None
            )
            enqueued_time_stamp = event_data.message.delivery_annotations.get(
                Constants.PROP_LAST_ENQUEUED_TIME_UTC, None
            )
            if enqueued_time_stamp:
                enqueued_time_stamp = Helpers.utc_from_timestamp(float(enqueued_time_stamp) / 1000)
            retrieval_time_stamp = event_data.message.delivery_annotations.get(
                Constants.PROP_RUNTIME_INFO_RETRIEVAL_TIME_UTC, None
            )
            if retrieval_time_stamp:
                retrieval_time_stamp = Helpers.utc_from_timestamp(
                    float(retrieval_time_stamp) / 1000
                )
            offset_bytes = event_data.message.delivery_annotations.get(
                Constants.PROP_LAST_ENQUEUED_OFFSET, None
            )
            offset = offset_bytes.decode("UTF-8") if offset_bytes else None

            event_data._last_enqueued_event_properties = {
                "sequence_number": sequence_number,
                "offset": offset,
                "enqueued_time": enqueued_time_stamp,
                "retrieval_time": retrieval_time_stamp,
            }
            return event_data._last_enqueued_event_properties
        return None


class Constants():
    # Event hub constants
    PROP_SEQ_NUMBER = b"x-opt-sequence-number"
    PROP_OFFSET = b"x-opt-offset"
    PROP_PARTITION_KEY = b"x-opt-partition-key"
    PROP_PARTITION_KEY_AMQP_SYMBOL = types.AMQPSymbol(PROP_PARTITION_KEY)
    PROP_TIMESTAMP = b"x-opt-enqueued-time"
    PROP_LAST_ENQUEUED_SEQUENCE_NUMBER = b"last_enqueued_sequence_number"
    PROP_LAST_ENQUEUED_OFFSET = b"last_enqueued_offset"
    PROP_LAST_ENQUEUED_TIME_UTC = b"last_enqueued_time_utc"
    PROP_RUNTIME_INFO_RETRIEVAL_TIME_UTC = b"runtime_info_retrieval_time_utc"

    PROP_MESSAGE_ID = b"message-id"
    PROP_USER_ID = b"user-id"
    PROP_TO = b"to"
    PROP_SUBJECT = b"subject"
    PROP_REPLY_TO = b"reply-to"
    PROP_CORRELATION_ID = b"correlation-id"
    PROP_CONTENT_TYPE = b"content-type"
    PROP_CONTENT_ENCODING = b"content-encoding"
    PROP_ABSOLUTE_EXPIRY_TIME = b"absolute-expiry-time"
    PROP_CREATION_TIME = b"creation-time"
    PROP_GROUP_ID = b"group-id"
    PROP_GROUP_SEQUENCE = b"group-sequence"
    PROP_REPLY_TO_GROUP_ID = b"reply-to-group-id"

    EPOCH_SYMBOL = b"com.microsoft:epoch"
    TIMEOUT_SYMBOL = b"com.microsoft:timeout"
    RECEIVER_RUNTIME_METRIC_SYMBOL = b"com.microsoft:enable-receiver-runtime-metric"

    MAX_USER_AGENT_LENGTH = 512
    ALL_PARTITIONS = "all-partitions"
    CONTAINER_PREFIX = "eventhub.pysdk-"
    JWT_TOKEN_SCOPE = "https://eventhubs.azure.net//.default"
    MGMT_OPERATION = b"com.microsoft:eventhub"
    MGMT_PARTITION_OPERATION = b"com.microsoft:partition"
    MGMT_STATUS_CODE = b'status-code'
    MGMT_STATUS_DESC = b'status-description'
    USER_AGENT_PREFIX = "azsdk-python-eventhubs"

    NO_RETRY_ERRORS = (
        b"com.microsoft:argument-out-of-range",
        b"com.microsoft:entity-disabled",
        b"com.microsoft:auth-failed",
        b"com.microsoft:precondition-failed",
        b"com.microsoft:argument-error",
    )