from requests import Session, codes
from unittest import TestCase
from unittest.mock import Mock, patch
from uuid import uuid4


from azext_xsignextension.EsrpLogger import EsrpLogger
from azext_xsignextension.eventhub.EventHubClient import EventData, EventHubProducerClient
from azext_xsignextension.Contracts.LogData import LogLevel
from azext_xsignextension.Contracts.Status import CurrentStatus
from azext_xsignextension.Contracts.LogData import LogEvent


class TestEsrpLogger(TestCase):

    @patch.object(EventHubProducerClient, 'from_connection_string')
    def test_generate_telemetry_message_details(self, mock_event_hub_client):
        logger = EsrpLogger(connection_string="test_connection_string")
        logger.client_id = str(uuid4())
        event_name="happy mock test"
        log_level = LogLevel.Informational
        status = "happy mock status"
        message = logger.generate_telemetry_message(event_name=event_name, level=log_level, status=status)
        self.assertTrue(event_name in message)


    @patch.object(EventHubProducerClient, 'from_connection_string')
    def test_generate_telemetry_message_status(self, mock_event_hub_client):
        logger = EsrpLogger(connection_string="test_connection_string")
        logger.client_id = str(uuid4())
        event_name="happy mock test"
        status = CurrentStatus()

        log_level = LogLevel.Informational
        message = logger.generate_telemetry_message(event_name=event_name, level=log_level, status=status)
        self.assertTrue(event_name in message)

    @patch.object(EventHubProducerClient, 'from_connection_string')
    @patch.object(EventHubProducerClient, 'send_batch')
    def test_informational(self, mock_event_hub_client, mock_event_hub_send_batch):
        logger = EsrpLogger(connection_string="test_connection_string")
        logger.client_id = str(uuid4())
        event_name="happy mock test informational"
        try:
            logger.informational(event=event_name, details="test details")
        except:
            self.fail()

    @patch.object(EventHubProducerClient, 'from_connection_string')
    @patch.object(EventHubProducerClient, 'send_batch')
    def test_error(self, mock_event_hub_client, mock_event_hub_send_batch):
        logger = EsrpLogger(connection_string="test_connection_string")
        logger.client_id = str(uuid4())
        event_name="happy mock test error"
        try:
            logger.error(event=event_name, details="test details")
        except:
            self.fail()

    @patch.object(EventHubProducerClient, 'from_connection_string')
    @patch.object(EventHubProducerClient, 'send_batch')
    def test_create_event(self, mock_event_hub_client, mock_event_hub_send_batch):
        logger = EsrpLogger(connection_string="test_connection_string")
        logger.client_id = str(uuid4())
        event_name="happy mock test informational"
        log_event = LogEvent(client_id=logger.client_id, level=LogLevel.Informational, event=event_name, details="mock details")
        event = logger.create_event(log_event=log_event)
        self.assertTrue(event_name in event)
        self.assertTrue(logger.client_id in event)


    @patch.object(EventHubProducerClient, 'from_connection_string')
    @patch.object(EventHubProducerClient, 'send_batch')
    def test_send_batch(self, mock_event_hub_client, mock_event_hub_send_batch):
        logger = EsrpLogger(connection_string="test_connection_string")
        logger.client_id = str(uuid4())
        event_name="happy mock test informational"
        log_event = LogEvent(client_id=logger.client_id, level=LogLevel.Informational, event=event_name, details="mock details")
        event = logger.create_event(log_event=log_event)
        try:
            logger.send_event(event)
        except:
            self.fail()