import os

from unittest import TestCase, skip

from azext_xsignextension.__init__ import sign_file
from azext_xsignextension.ConfigFile import ConfigFile
from azext_xsignextension.EsrpSign import EsrpSign




class TestE2EIntegrationPass(TestCase):
    def test_sign_file_pass(self):
        config_file = os.path.abspath('./TestResources/config-apple.json')
        file_name = os.path.abspath('./TestResources/Microsoft To-Do.zip')
        signed_file_name = os.path.abspath('./TestResources/Microsoft To-Do_signed.zip')
        config = ConfigFile(config_file)
        esrp_sign = EsrpSign(file_path=file_name, config=config, signed_file_path=signed_file_name)
        esrp_sign.sign_file()
