import builtins
import os
import pathlib
import pytest
import re

from base64 import b64encode
from time import sleep
from unittest import TestCase
from unittest.mock import MagicMock, Mock, patch, mock_open
from uuid import uuid4

from azext_xsignextension.Contracts.Status import CurrentStatus
from azext_xsignextension.Helpers import Helpers





class responseObject(object):
    def __init__(self, status_code):
        self.status_code = status_code


class TestHelpers(TestCase):

    def test_hash_file(self):
        file_name = os.path.join(os.path.dirname(os.path.realpath(__file__)), "helloworld.txt")
        hash = Helpers.hash_file(file_name)

        self.assertEqual(hash.hex(), "03675ac53ff9cd1535ccc7dfcdfa2c458c5218371f418dc136f2d19ac1fbe8a5")

    def test_check_hash_match(self):
        file_name = os.path.join(os.path.dirname(os.path.realpath(__file__)), "helloworld.txt")
        hash = str(b64encode(Helpers.hash_file(file_name)), 'utf-8')
        destination_hash = "A2daxT/5zRU1zMffzfosRYxSGDcfQY3BNvLRmsH76KU="
        self.assertEqual(hash, destination_hash)



    def test_generate_blob_url_with_extension(self):
        testurl = "https://Captain.blob.America/Marvel/Iron?Man"

        newurl = Helpers.generate_blob_url_with_extension(testurl, "Thors.Mjolnir")
        match = re.search((r"http(s)?://(?P<account_name>.*?)\.blob\.(?P<endpoint_suffix>.*?)/(?P<container_name>.*?)/"
                        r"(?P<blob_name>.*?)\?(?P<sas_token>.*)"), newurl)

        self.assertEqual(match.group("account_name"), "Captain")
        self.assertEqual(match.group("endpoint_suffix"), "America")
        self.assertEqual(match.group("container_name"), "Marvel")
        self.assertEqual(match.group("sas_token"), "Man")
        self.assertEqual(pathlib.Path(match.group("blob_name")).suffixes, [".Mjolnir"])


    def test_parse_response(self):
        testDict = {"200": True, "201": True, "202": True, "400": False, "401": False, "500": False }

        for test in testDict:
            objResponse = responseObject(int(test))
            self.assertEqual(Helpers.parse_response(objResponse), testDict[test])


    @patch.object(Helpers, 'get_access_token_from_cli', return_value={"accessToken": "Hello, World"})
    def test_get_auth_bearer_token(self, mock_get_access_token_from_cli):
        token = Helpers.get_auth_bearer_token("MyUrl")

        self.assertEqual(token["accessToken"], "Hello, World")


    def test_toJson(self):
        objectJson = {}
        objectJson["1"] = "The Avengers"
        objectJson["2"] = "Age of Ultron"
        objectJson["3"] = "Infinity War"
        objectJson["4"] = "Endgame"

        jsonStr = Helpers.toJson(objectJson)

        self.assertEqual(str(jsonStr), "{\"1\": \"The Avengers\", \"2\": \"Age of Ultron\", \"3\": \"Infinity War\", \"4\": \"Endgame\"}")


    @patch.object(Helpers, 'print_to_console', autospec=True)
    def test_resultSummary(self, mock_print_to_console):
        status = CurrentStatus()
        status.esrpAzCliSessionId = str(uuid4())
        status.operationId = str(uuid4())
        status.fileUploadStatus.hash = "Test hash"
        status.fileUploadStatus.file_size = 0
        status.fileUploadStatus.file_path = "Test path"
        status.fileDownloadStatus.file_path = "Test path"
        status.fileDownloadStatus.file_size = 0
        status.fileDownloadStatus.hash = "Test hash"
        status.signFileStatus.status = "pass"
        status.error_details = ""

        mock_print_to_console.return_value = ""

        with patch('builtins.open', mock_open()) as m:
            Helpers.write_result_json(status, "test.json")


    def test_timeout(self):
        try:
            self.timeout_example()
            self.fail()
        except Exception as ex:
            template = "An exception of type {0} occurred. Arguments:\n{1!r}"
            message = template.format(type(ex).__name__, ex.args)
            self.assertTrue("TimeoutError" in message)
        
        
    @Helpers.timeout_decorator(1)
    def timeout_example(self):
        sleep(2)
        pass
