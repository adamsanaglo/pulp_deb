from uuid import uuid4
from requests import Session
from unittest import TestCase
from unittest.mock import Mock, patch

from azext_xsignextension.EsrpGatewayClient import EsrpGatewayClient



class MockResponse:
    def __init__(self, status_code, text=None, content=None):
        self.status_code = status_code
        self.content = "pass"
        self.text = "pass"

class TestEsrpGatewayClient(TestCase):
    @patch.object(Session, 'post', return_value=MockResponse(status_code=202))    
    def test_create_session(self, mock_get):
        gateway_api = "https://ess-gateway-ppe.trafficmanager.net"
        client_id = str(uuid4()) 
        bearer_auth_token = 'bearer token mock'
        esrp_gateway_client = EsrpGatewayClient(gateway_api, client_id)

        payload = {'create_session': 'mock'}
        response = esrp_gateway_client.create_session(bearer_auth=bearer_auth_token, payload=payload)
        self.assertEqual(response.content, "pass")


    @patch.object(Session, 'get', return_value=MockResponse(status_code=200))    
    def test_query_sign_status(self, mock_get):
        gateway_api = "https://ess-gateway-ppe.trafficmanager.net"
        client_id = str(uuid4()) 
        bearer_auth_token = 'bearer token mock'
        operation_id = str(uuid4())
        esrp_gateway_client = EsrpGatewayClient(gateway_api, client_id)
        response = esrp_gateway_client.query_sign_status(bearer_auth=bearer_auth_token, operation_id=operation_id)
        self.assertEqual(response.content, "pass")


    @patch.object(Session, 'post', return_value=MockResponse(status_code=202))    
    def test_submit_to_sign_file(self, mock_get):
        gateway_api = "https://ess-gateway-ppe.trafficmanager.net"
        client_id = str(uuid4()) 
        bearer_auth_token = 'bearer token mock'
        esrp_gateway_client = EsrpGatewayClient(gateway_api, client_id)
        payload = {'submit_to_sign': 'mock'}
        response = esrp_gateway_client.submit_to_sign_file(bearer_auth=bearer_auth_token, request_json=payload)
        self.assertEqual(response.content, "pass")



