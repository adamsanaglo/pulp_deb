import os
import sys

from requests import Session, codes
from unittest import TestCase
from unittest.mock import Mock, patch, MagicMock
from uuid import uuid4

from azext_xsignextension.ConfigFile import ConfigFile
from azext_xsignextension.Contracts.Status import CurrentStatus
from azext_xsignextension.EsrpSign import EsrpSign
from azext_xsignextension.EsrpLogger import EsrpLogger
from azext_xsignextension.EsrpGatewayClient import EsrpGatewayClient
from azext_xsignextension.Helpers import Helpers


class TestEsrpSign(TestCase):

    class MockResponse:
        def __init__(self, status_code=None, headers=None, content=None, status=None, json_dict=None):
            self.status_code = status_code
            self.content = content
            self.json_dict=json_dict
            self.status = status
            self.headers=headers
            with open(os.path.abspath('./azext_xsignextension/tests/test-session-response.txt'), 'r') as f:
                self.text = f.read()

        def json(self):
            return self.json_dict



    @patch.object(EsrpLogger, 'error', return_value=MockResponse())
    def test_log_status_error(self, mock_log):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")
        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        try:
            esrp_sign.log_status("Test", error=True)
            self.assertTrue(True)
        except:
            self.fail()


    @patch.object(EsrpLogger, 'informational', return_value=MockResponse())    
    def test_log_status_informational(self, mock_log):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        try:
            esrp_sign.log_status("Test")
        except:
            self.fail()


    @patch.object(EsrpGatewayClient, 'create_session', return_value=MockResponse(status_code=200, status="pass"))    
    @patch.object(EsrpSign, 'setup_telemetry_client', return_value=None)    
    def test_create_session_pass(self, mock_create_session, mock_setup_telemetry_client):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        esrp_sign.esrp_client = EsrpGatewayClient()
        response = esrp_sign.create_session()
        self.assertEqual(response.status, "pass")


    @patch.object(EsrpGatewayClient, 'create_session', return_value=MockResponse(status_code=403, headers="forbidden"))
    @patch.object(EsrpSign, 'setup_telemetry_client', return_value=None)
    def test_create_session_fail(self, mock_create_session, mock_setup_telemetry_client):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        sys.exit = MagicMock()

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        esrp_sign.esrp_client = EsrpGatewayClient()

        esrp_sign.create_session()
        assert sys.exit.called


    @patch.object(EsrpSign, 'log_status')
    @patch.object(Helpers, 'download_blob')
    def test_download_file(self, mock_download_blob, mock_log_status):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        try:
            esrp_sign.download_file('bloburl', 'destination_hash', 'test')
        except:
            self.fail()


    @patch.object(EsrpSign, 'log_status')
    @patch.object(Helpers, 'upload_blob')
    def test_upload_file(self, mock_upload_blob, mock_log_status):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)

        try:
            esrp_sign.upload_file('bloburl', 'test')
        except:
            self.fail()


    def test_generate_sign_request_message(self):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        sign_request_message = esrp_sign.generate_sign_request_message(source_blob_url='source_blob', destination_blob_url='destination_blob')
        self.assertEqual('source_blob', sign_request_message.file.sourceLocation.blobUrl)
        self.assertEqual('destination_blob', sign_request_message.file.destinationLocation.blobUrl)


    @patch.object(Helpers, 'generate_jws_token', return_value=b'1')
    def test_prepare_sign_request_msg(self, mock_generate_jws_token):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        sign_request_json = esrp_sign.prepare_sign_request_msg(source_blob_url='source_blob', destination_blob_url='destination_blob')
        self.assertTrue('source_blob' in sign_request_json)
        self.assertTrue('destination_blob' in sign_request_json)


    @patch.object(EsrpGatewayClient, 'query_sign_status', return_value=MockResponse(json_dict={'status': 'pass', 'destinationLocation':{'bloburl': 'destination_blob'}}))
    def test_query_sign_status_pass(self, mock_esrp_client):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        esrp_sign.esrp_client = EsrpGatewayClient()
        esrp_sign.query_sign_status()
        self.assertTrue(esrp_sign.status.signFileStatus.status, "pass")



    @patch.object(EsrpGatewayClient, 'query_sign_status', return_value=None)
    def test_query_sign_status_no_response(self, mock_esrp_client):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        sys.exit = Mock()
        sys.exit.side_effect = Exception('Test')

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        esrp_sign.esrp_client = EsrpGatewayClient()
        try:
            esrp_sign.query_sign_status()
            self.fail()
        except Exception:
            self.assertTrue(esrp_sign.status.signFileStatus.status, "failDoNotRetry")


    @patch.object(EsrpGatewayClient, 'query_sign_status', return_value=MockResponse(json_dict={'status': 'failDoNotRetry', 'destinationLocation':{'bloburl': 'destination_blob'}}))
    def test_query_sign_status_fdnr(self, mock_esrp_client):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        sys.exit = Mock()
        sys.exit.side_effect = Exception('Test')

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        esrp_sign.esrp_client = EsrpGatewayClient()

        try:
            esrp_sign.query_sign_status()
            self.fail()
        except Exception:
            self.assertTrue(esrp_sign.status.signFileStatus.status, "failDoNotRetry")

    @patch.object(EsrpGatewayClient, 'query_sign_status', return_value=MockResponse(json_dict={'status': 'pendingAnalysis', 'destinationLocation':{'bloburl': 'destination_blob'}}))
    def test_query_sign_status_pending_analysis(self, mock_esrp_client):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        sys.exit = Mock()
        sys.exit.side_effect = Exception('Test')

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        esrp_sign.esrp_client = EsrpGatewayClient()

        try:
            esrp_sign.query_sign_status()
            self.fail()
        except Exception:
            self.assertTrue(esrp_sign.status.signFileStatus.status, "pendingAnalysis")



    @patch.object(EsrpGatewayClient, 'query_sign_status', return_value=MockResponse(json_dict={'status': 'failCanRetry', 'destinationLocation':{'bloburl': 'destination_blob'}}))
    def test_query_sign_status_fcr(self, mock_esrp_client):
        config_file = os.path.abspath("./TestResources/config-apple.json")
        file_to_sign = os.path.abspath("./TestResources/Microsoft To-Do.zip")
        signed_file_path = os.path.abspath("./TestResources/Microsoft To-Do-signed.zip")

        config = ConfigFile(config_file)

        sys.exit = Mock()
        sys.exit.side_effect = Exception('Test')

        esrp_sign = EsrpSign(config=config, file_path=file_to_sign, signed_file_path=signed_file_path)
        esrp_sign.esrp_client = EsrpGatewayClient()
        try:
            esrp_sign.query_sign_status()
            self.fail()
        except Exception:
            self.assertTrue(esrp_sign.status.signFileStatus.status, "failCanRetry")
