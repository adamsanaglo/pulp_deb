from io import BytesIO
from typing import ( 
    Union, Optional, Any, IO, Iterable, AnyStr, Dict, List, Tuple,
    TYPE_CHECKING
)
try:
    from urllib.parse import urlparse, quote, unquote
except ImportError:
    from urlparse import urlparse 
    from urllib2 import quote, unquote 

import six
from azure.core.tracing.decorator import distributed_trace

from ._shared.base_client import StorageAccountHostsMixin, parse_connection_str, parse_query
from ._shared.uploads import IterStreamer
from ._shared.request_handlers import (
    add_metadata_headers, get_length )
from ._generated import AzureBlobStorage
from ._generated.models import BlobHTTPHeaders
from ._serialize import (
    get_modify_conditions,
)
from ._deserialize import deserialize_blob_stream
from ._upload_helpers import upload_block_blob
from ._models import BlobType
from ._download import StorageStreamDownloader
from ._lease import get_access_conditions



class BlobClient(StorageAccountHostsMixin):
    def __init__(
            self, account_url,  
            container_name,  
            blob_name,  
            snapshot=None,  
            credential=None,  
            **kwargs  
        ):
        try:
            if not account_url.lower().startswith('http'):
                account_url = "https://" + account_url
        except AttributeError:
            raise ValueError("Account URL must be a string.")
        parsed_url = urlparse(account_url.rstrip('/'))

        if not (container_name and blob_name):
            raise ValueError("Please specify a container name and blob name.")
        if not parsed_url.netloc:
            raise ValueError("Invalid URL: {}".format(account_url))

        path_snapshot, sas_token = parse_query(parsed_url.query)

        self.container_name = container_name
        self.blob_name = blob_name

        try:
            self.snapshot = snapshot.snapshot 
        except AttributeError:
            try:
                self.snapshot = snapshot['snapshot'] 
            except TypeError:
                self.snapshot = snapshot or path_snapshot

        self._query_str, credential = self._format_query_string(sas_token, credential, snapshot=self.snapshot)
        super(BlobClient, self).__init__(parsed_url, service='blob', credential=credential, **kwargs)
        self._client = AzureBlobStorage(self.url, pipeline=self._pipeline)

    def _format_url(self, hostname):
        container_name = self.container_name
        if isinstance(container_name, six.text_type):
            container_name = container_name.encode('UTF-8')
        return "{}://{}/{}/{}{}".format(
            self.scheme,
            hostname,
            quote(container_name),
            quote(self.blob_name, safe='~/'),
            self._query_str)

    @classmethod
    def from_blob_url(cls, blob_url, credential=None, snapshot=None, **kwargs):
        try:
            if not blob_url.lower().startswith('http'):
                blob_url = "https://" + blob_url
        except AttributeError:
            raise ValueError("Blob URL must be a string.")
        parsed_url = urlparse(blob_url.rstrip('/'))

        if not parsed_url.netloc:
            raise ValueError("Invalid URL: {}".format(blob_url))

        account_path = ""
        if ".core." in parsed_url.netloc:
            # .core. is indicating non-customized url. Blob name with directory info can also be parsed.
            path_blob = parsed_url.path.lstrip('/').split('/', 1)
        elif "localhost" in parsed_url.netloc or "127.0.0.1" in parsed_url.netloc:
            path_blob = parsed_url.path.lstrip('/').split('/', 2)
            account_path += path_blob[0]
        else:
            # for customized url. blob name that has directory info cannot be parsed.
            path_blob = parsed_url.path.lstrip('/').split('/')
            if len(path_blob) > 2:
                account_path = "/" + "/".join(path_blob[:-2])
        account_url = "{}://{}{}?{}".format(
            parsed_url.scheme,
            parsed_url.netloc.rstrip('/'),
            account_path,
            parsed_url.query)
        container_name, blob_name = unquote(path_blob[-2]), unquote(path_blob[-1])
        if not container_name or not blob_name:
            raise ValueError("Invalid URL. Provide a blob_url with a valid blob and container name.")

        path_snapshot, _ = parse_query(parsed_url.query)
        if snapshot:
            try:
                path_snapshot = snapshot.snapshot # type: ignore
            except AttributeError:
                try:
                    path_snapshot = snapshot['snapshot'] # type: ignore
                except TypeError:
                    path_snapshot = snapshot

        return cls(
            account_url, container_name=container_name, blob_name=blob_name,
            snapshot=path_snapshot, credential=credential, **kwargs
        )

    @classmethod
    def from_connection_string(
            cls, conn_str, 
            container_name, 
            blob_name,
            snapshot=None,
            credential=None,
            **kwargs
        ):
        account_url, secondary, credential = parse_connection_str(conn_str, credential, 'blob')
        if 'secondary_hostname' not in kwargs:
            kwargs['secondary_hostname'] = secondary
        return cls(
            account_url, container_name=container_name, blob_name=blob_name,
            snapshot=snapshot, credential=credential, **kwargs
        )

    def _upload_blob_options( 
            self, data,  
            blob_type=BlobType.BlockBlob, 
            length=None, 
            metadata=None, 
            **kwargs
        ):

        encoding = kwargs.pop('encoding', 'UTF-8')
        if isinstance(data, six.text_type):
            data = data.encode(encoding) # type: ignore
        if length is None:
            length = get_length(data)
        if isinstance(data, bytes):
            data = data[:length]

        if isinstance(data, bytes):
            stream = BytesIO(data)
        elif hasattr(data, 'read'):
            stream = data
        elif hasattr(data, '__iter__'):
            stream = IterStreamer(data, encoding=encoding)
        else:
            raise TypeError("Unsupported data type: {}".format(type(data)))

        validate_content = kwargs.pop('validate_content', False)
        content_settings = kwargs.pop('content_settings', None)
        overwrite = kwargs.pop('overwrite', False)
        max_concurrency = kwargs.pop('max_concurrency', 1)

        headers = kwargs.pop('headers', {})
        headers.update(add_metadata_headers(metadata))
        kwargs['lease_access_conditions'] = get_access_conditions(kwargs.pop('lease', None))
        kwargs['modified_access_conditions'] = get_modify_conditions(kwargs)
        if content_settings:
            kwargs['blob_headers'] = BlobHTTPHeaders(
                blob_cache_control=content_settings.cache_control,
                blob_content_type=content_settings.content_type,
                blob_content_md5=bytearray(content_settings.content_md5) if content_settings.content_md5 else None,
                blob_content_encoding=content_settings.content_encoding,
                blob_content_language=content_settings.content_language,
                blob_content_disposition=content_settings.content_disposition
            )
        kwargs['stream'] = stream
        kwargs['length'] = length
        kwargs['overwrite'] = overwrite
        kwargs['headers'] = headers
        kwargs['validate_content'] = validate_content
        kwargs['blob_settings'] = self._config
        kwargs['max_concurrency'] = max_concurrency
        if blob_type == BlobType.BlockBlob:
            kwargs['client'] = self._client.block_blob
            kwargs['data'] = data
        elif blob_type == BlobType.PageBlob:
            kwargs['client'] = self._client.page_blob
        else:
            raise ValueError("Unsupported BlobType: {}".format(blob_type))
        return kwargs

    @distributed_trace
    def upload_blob(  
            self, data,
            blob_type=BlobType.BlockBlob,
            length=None, 
            metadata=None, 
            **kwargs
        ):
        options = self._upload_blob_options(
            data,
            blob_type=blob_type,
            length=length,
            metadata=metadata,
            **kwargs)
        return upload_block_blob(**options)

    def _download_blob_options(self, offset=None, length=None, **kwargs):
        if length is not None and offset is None:
            raise ValueError("Offset value must not be None if length is set.")
        if length is not None:
            length = offset + length - 1  # Service actually uses an end-range inclusive index

        validate_content = kwargs.pop('validate_content', False)
        access_conditions = get_access_conditions(kwargs.pop('lease', None))
        mod_conditions = get_modify_conditions(kwargs)

        options = {
            'clients': self._client,
            'config': self._config,
            'start_range': offset,
            'end_range': length,
            'validate_content': validate_content,
            'lease_access_conditions': access_conditions,
            'modified_access_conditions': mod_conditions,
            'cls': deserialize_blob_stream,
            'max_concurrency':kwargs.pop('max_concurrency', 1),
            'encoding': kwargs.pop('encoding', None),
            'timeout': kwargs.pop('timeout', None),
            'name': self.blob_name,
            'container': self.container_name}
        options.update(kwargs)
        return options

    @distributed_trace
    def download_blob(self, offset=None, length=None, **kwargs):
       
        options = self._download_blob_options(
            offset=offset,
            length=length,
            **kwargs)
        return StorageStreamDownloader(**options)