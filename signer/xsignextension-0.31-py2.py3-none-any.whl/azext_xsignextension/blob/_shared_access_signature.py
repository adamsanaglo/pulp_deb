from typing import (  # pylint: disable=unused-import
    Union, Optional, Any, TYPE_CHECKING
)

from azext_xsignextension.blob._shared import sign_string, url_quote
from azext_xsignextension.blob._shared.models import Services
from azext_xsignextension.blob._shared.shared_access_signature import SharedAccessSignature, _SharedAccessHelper, \
    QueryStringConstants

if TYPE_CHECKING:
    from datetime import datetime
    from azext_xsignextension.blob import (
        ResourceTypes,
        AccountSasPermissions
    )


class BlobQueryStringConstants(object):
    SIGNED_TIMESTAMP = 'snapshot'


class BlobSharedAccessSignature(SharedAccessSignature):
    def __init__(self, account_name, account_key=None, user_delegation_key=None):
        super(BlobSharedAccessSignature, self).__init__(account_name, account_key)
        self.user_delegation_key = user_delegation_key

    def generate_blob(self, container_name, blob_name, snapshot=None, version_id=None, permission=None,
                      expiry=None, start=None, policy_id=None, ip=None, protocol=None,
                      cache_control=None, content_disposition=None,
                      content_encoding=None, content_language=None,
                      content_type=None):
        resource_path = container_name + '/' + blob_name

        sas = _BlobSharedAccessHelper()
        sas.add_base(permission, expiry, start, ip, protocol)
        sas.add_id(policy_id)

        resource = 'bs' if snapshot else 'b'
        resource = 'bv' if version_id else resource
        sas.add_resource(resource)

        sas.add_timestamp(snapshot or version_id)
        sas.add_override_response_headers(cache_control, content_disposition,
                                          content_encoding, content_language,
                                          content_type)
        sas.add_resource_signature(self.account_name, self.account_key, resource_path,
                                   user_delegation_key=self.user_delegation_key)

        return sas.get_token()

    def generate_container(self, container_name, permission=None, expiry=None,
                           start=None, policy_id=None, ip=None, protocol=None,
                           cache_control=None, content_disposition=None,
                           content_encoding=None, content_language=None,
                           content_type=None):
        sas = _BlobSharedAccessHelper()
        sas.add_base(permission, expiry, start, ip, protocol)
        sas.add_id(policy_id)
        sas.add_resource('c')
        sas.add_override_response_headers(cache_control, content_disposition,
                                          content_encoding, content_language,
                                          content_type)
        sas.add_resource_signature(self.account_name, self.account_key, container_name,
                                   user_delegation_key=self.user_delegation_key)
        return sas.get_token()


class _BlobSharedAccessHelper(_SharedAccessHelper):

    def add_timestamp(self, timestamp):
        self._add_query(BlobQueryStringConstants.SIGNED_TIMESTAMP, timestamp)

    def get_value_to_append(self, query):
        return_value = self.query_dict.get(query) or ''
        return return_value + '\n'

    def add_resource_signature(self, account_name, account_key, path, user_delegation_key=None):
        # pylint: disable = no-member
        if path[0] != '/':
            path = '/' + path

        canonicalized_resource = '/blob/' + account_name + path + '\n'

        # Form the string to sign from shared_access_policy and canonicalized
        # resource. The order of values is important.
        string_to_sign = \
            (self.get_value_to_append(QueryStringConstants.SIGNED_PERMISSION) +
             self.get_value_to_append(QueryStringConstants.SIGNED_START) +
             self.get_value_to_append(QueryStringConstants.SIGNED_EXPIRY) +
             canonicalized_resource)

        if user_delegation_key is not None:
            self._add_query(QueryStringConstants.SIGNED_OID, user_delegation_key.signed_oid)
            self._add_query(QueryStringConstants.SIGNED_TID, user_delegation_key.signed_tid)
            self._add_query(QueryStringConstants.SIGNED_KEY_START, user_delegation_key.signed_start)
            self._add_query(QueryStringConstants.SIGNED_KEY_EXPIRY, user_delegation_key.signed_expiry)
            self._add_query(QueryStringConstants.SIGNED_KEY_SERVICE, user_delegation_key.signed_service)
            self._add_query(QueryStringConstants.SIGNED_KEY_VERSION, user_delegation_key.signed_version)

            string_to_sign += \
                (self.get_value_to_append(QueryStringConstants.SIGNED_OID) +
                 self.get_value_to_append(QueryStringConstants.SIGNED_TID) +
                 self.get_value_to_append(QueryStringConstants.SIGNED_KEY_START) +
                 self.get_value_to_append(QueryStringConstants.SIGNED_KEY_EXPIRY) +
                 self.get_value_to_append(QueryStringConstants.SIGNED_KEY_SERVICE) +
                 self.get_value_to_append(QueryStringConstants.SIGNED_KEY_VERSION))
        else:
            string_to_sign += self.get_value_to_append(QueryStringConstants.SIGNED_IDENTIFIER)

        string_to_sign += \
            (self.get_value_to_append(QueryStringConstants.SIGNED_IP) +
             self.get_value_to_append(QueryStringConstants.SIGNED_PROTOCOL) +
             self.get_value_to_append(QueryStringConstants.SIGNED_VERSION) +
             self.get_value_to_append(QueryStringConstants.SIGNED_RESOURCE) +
             self.get_value_to_append(BlobQueryStringConstants.SIGNED_TIMESTAMP) +
             self.get_value_to_append(QueryStringConstants.SIGNED_CACHE_CONTROL) +
             self.get_value_to_append(QueryStringConstants.SIGNED_CONTENT_DISPOSITION) +
             self.get_value_to_append(QueryStringConstants.SIGNED_CONTENT_ENCODING) +
             self.get_value_to_append(QueryStringConstants.SIGNED_CONTENT_LANGUAGE) +
             self.get_value_to_append(QueryStringConstants.SIGNED_CONTENT_TYPE))

        # remove the trailing newline
        if string_to_sign[-1] == '\n':
            string_to_sign = string_to_sign[:-1]

        self._add_query(QueryStringConstants.SIGNED_SIGNATURE,
                        sign_string(account_key if user_delegation_key is None else user_delegation_key.value,
                                    string_to_sign))

    def get_token(self):
        # a conscious decision was made to exclude the timestamp in the generated token
        # this is to avoid having two snapshot ids in the query parameters when the user appends the snapshot timestamp
        exclude = [BlobQueryStringConstants.SIGNED_TIMESTAMP]
        return '&'.join(['{0}={1}'.format(n, url_quote(v))
                         for n, v in self.query_dict.items() if v is not None and n not in exclude])


def generate_account_sas(
        account_name,  # type: str
        account_key,  # type: str
        resource_types,  # type: Union[ResourceTypes, str]
        permission,  # type: Union[AccountSasPermissions, str]
        expiry,  # type: Optional[Union[datetime, str]]
        start=None,  # type: Optional[Union[datetime, str]]
        ip=None,  # type: Optional[str]
        **kwargs # type: Any
    ):  # type: (...) -> str
    sas = SharedAccessSignature(account_name, account_key)
    return sas.generate_account(
        services=Services(blob=True),
        resource_types=resource_types,
        permission=permission,
        expiry=expiry,
        start=start,
        ip=ip,
        **kwargs
    ) 


def generate_container_sas(
        account_name,  
        container_name,  
        account_key=None,  
        user_delegation_key=None, 
        permission=None,  
        expiry=None,  
        start=None, 
        policy_id=None,  
        ip=None,  
        **kwargs
    ):
    
    if not user_delegation_key and not account_key:
        raise ValueError("Either user_delegation_key or account_key must be provided.")

    if user_delegation_key:
        sas = BlobSharedAccessSignature(account_name, user_delegation_key=user_delegation_key)
    else:
        sas = BlobSharedAccessSignature(account_name, account_key=account_key)
    return sas.generate_container(
        container_name,
        permission=permission,
        expiry=expiry,
        start=start,
        policy_id=policy_id,
        ip=ip,
        **kwargs
    )


def generate_blob_sas(
        account_name,  
        container_name,  
        blob_name,  
        snapshot=None,  
        account_key=None,  
        user_delegation_key=None,  
        permission=None,  
        expiry=None,  
        start=None,  
        policy_id=None,  
        ip=None, 
        **kwargs 
    ):
    if not user_delegation_key and not account_key:
        raise ValueError("Either user_delegation_key or account_key must be provided.")
    version_id = kwargs.pop('version_id', None)
    if version_id and snapshot:
        raise ValueError("snapshot and version_id cannot be set at the same time.")
    if user_delegation_key:
        sas = BlobSharedAccessSignature(account_name, user_delegation_key=user_delegation_key)
    else:
        sas = BlobSharedAccessSignature(account_name, account_key=account_key)
    return sas.generate_blob(
        container_name,
        blob_name,
        snapshot=snapshot,
        version_id=version_id,
        permission=permission,
        expiry=expiry,
        start=start,
        policy_id=policy_id,
        ip=ip,
        **kwargs
    )
