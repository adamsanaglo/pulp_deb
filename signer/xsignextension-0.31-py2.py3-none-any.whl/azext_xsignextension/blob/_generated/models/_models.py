from msrest.serialization import Model
from azure.core.exceptions import HttpResponseError



class BlobHTTPHeaders(Model):
    _attribute_map = {
        'blob_cache_control': {'key': '', 'type': 'str', 'xml': {'name': 'blob_cache_control'}},
        'blob_content_type': {'key': '', 'type': 'str', 'xml': {'name': 'blob_content_type'}},
        'blob_content_md5': {'key': '', 'type': 'bytearray', 'xml': {'name': 'blob_content_md5'}},
        'blob_content_encoding': {'key': '', 'type': 'str', 'xml': {'name': 'blob_content_encoding'}},
        'blob_content_language': {'key': '', 'type': 'str', 'xml': {'name': 'blob_content_language'}},
        'blob_content_disposition': {'key': '', 'type': 'str', 'xml': {'name': 'blob_content_disposition'}},
    }
    _xml_map = {
    }

    def __init__(self, *, blob_cache_control: str=None, blob_content_type: str=None, blob_content_md5: bytearray=None, blob_content_encoding: str=None, blob_content_language: str=None, blob_content_disposition: str=None, **kwargs) -> None:
        super(BlobHTTPHeaders, self).__init__(**kwargs)
        self.blob_cache_control = blob_cache_control
        self.blob_content_type = blob_content_type
        self.blob_content_md5 = blob_content_md5
        self.blob_content_encoding = blob_content_encoding
        self.blob_content_language = blob_content_language
        self.blob_content_disposition = blob_content_disposition


class BlockList(Model):
    _attribute_map = {
        'committed_blocks': {'key': 'CommittedBlocks', 'type': '[Block]', 'xml': {'name': 'CommittedBlocks', 'itemsName': 'Block', 'wrapped': True}},
        'uncommitted_blocks': {'key': 'UncommittedBlocks', 'type': '[Block]', 'xml': {'name': 'UncommittedBlocks', 'itemsName': 'Block', 'wrapped': True}},
    }
    _xml_map = {
    }

    def __init__(self, *, committed_blocks=None, uncommitted_blocks=None, **kwargs) -> None:
        super(BlockList, self).__init__(**kwargs)
        self.committed_blocks = committed_blocks
        self.uncommitted_blocks = uncommitted_blocks


class BlockLookupList(Model):
    _attribute_map = {
        'committed': {'key': 'Committed', 'type': '[str]', 'xml': {'name': 'Committed', 'itemsName': 'Committed'}},
        'uncommitted': {'key': 'Uncommitted', 'type': '[str]', 'xml': {'name': 'Uncommitted', 'itemsName': 'Uncommitted'}},
        'latest': {'key': 'Latest', 'type': '[str]', 'xml': {'name': 'Latest', 'itemsName': 'Latest'}},
    }
    _xml_map = {
        'name': 'BlockList'
    }

    def __init__(self, *, committed=None, uncommitted=None, latest=None, **kwargs) -> None:
        super(BlockLookupList, self).__init__(**kwargs)
        self.committed = committed
        self.uncommitted = uncommitted
        self.latest = latest




class DelimitedTextConfiguration(Model):
    _validation = {
        'column_separator': {'required': True},
        'field_quote': {'required': True},
        'record_separator': {'required': True},
        'escape_char': {'required': True},
        'headers_present': {'required': True},
    }

    _attribute_map = {
        'column_separator': {'key': 'ColumnSeparator', 'type': 'str', 'xml': {'name': 'ColumnSeparator'}},
        'field_quote': {'key': 'FieldQuote', 'type': 'str', 'xml': {'name': 'FieldQuote'}},
        'record_separator': {'key': 'RecordSeparator', 'type': 'str', 'xml': {'name': 'RecordSeparator'}},
        'escape_char': {'key': 'EscapeChar', 'type': 'str', 'xml': {'name': 'EscapeChar'}},
        'headers_present': {'key': 'HeadersPresent', 'type': 'bool', 'xml': {'name': 'HasHeaders'}},
    }
    _xml_map = {
        'name': 'DelimitedTextConfiguration'
    }

    def __init__(self, *, column_separator: str, field_quote: str, record_separator: str, escape_char: str, headers_present: bool, **kwargs) -> None:
        super(DelimitedTextConfiguration, self).__init__(**kwargs)
        self.column_separator = column_separator
        self.field_quote = field_quote
        self.record_separator = record_separator
        self.escape_char = escape_char
        self.headers_present = headers_present


class JsonTextConfiguration(Model):
    _validation = {
        'record_separator': {'required': True},
    }

    _attribute_map = {
        'record_separator': {'key': 'RecordSeparator', 'type': 'str', 'xml': {'name': 'RecordSeparator'}},
    }
    _xml_map = {
        'name': 'JsonTextConfiguration'
    }

    def __init__(self, *, record_separator: str, **kwargs) -> None:
        super(JsonTextConfiguration, self).__init__(**kwargs)
        self.record_separator = record_separator


class LeaseAccessConditions(Model):
    _attribute_map = {
        'lease_id': {'key': '', 'type': 'str', 'xml': {'name': 'lease_id'}},
    }
    _xml_map = {
    }

    def __init__(self, *, lease_id: str=None, **kwargs) -> None:
        super(LeaseAccessConditions, self).__init__(**kwargs)
        self.lease_id = lease_id



class ModifiedAccessConditions(Model):

    _attribute_map = {
        'if_modified_since': {'key': '', 'type': 'rfc-1123', 'xml': {'name': 'if_modified_since'}},
        'if_unmodified_since': {'key': '', 'type': 'rfc-1123', 'xml': {'name': 'if_unmodified_since'}},
        'if_match': {'key': '', 'type': 'str', 'xml': {'name': 'if_match'}},
        'if_none_match': {'key': '', 'type': 'str', 'xml': {'name': 'if_none_match'}}
    }
    _xml_map = {
    }

    def __init__(self, *, if_modified_since=None, if_unmodified_since=None, if_match: str=None, if_none_match: str=None, **kwargs) -> None:
        super(ModifiedAccessConditions, self).__init__(**kwargs)
        self.if_modified_since = if_modified_since
        self.if_unmodified_since = if_unmodified_since
        self.if_match = if_match
        self.if_none_match = if_none_match


class QueryFormat(Model):
    _attribute_map = {
        'type': {'key': 'Type', 'type': 'QueryFormatType', 'xml': {'name': 'Type'}},
        'delimited_text_configuration': {'key': 'DelimitedTextConfiguration', 'type': 'DelimitedTextConfiguration', 'xml': {'name': 'DelimitedTextConfiguration'}},
        'json_text_configuration': {'key': 'JsonTextConfiguration', 'type': 'JsonTextConfiguration', 'xml': {'name': 'JsonTextConfiguration'}},
    }
    _xml_map = {
    }

    def __init__(self, *, type=None, delimited_text_configuration=None, json_text_configuration=None, **kwargs) -> None:
        super(QueryFormat, self).__init__(**kwargs)
        self.type = type
        self.delimited_text_configuration = delimited_text_configuration
        self.json_text_configuration = json_text_configuration


class QueryRequest(Model):
    _validation = {
        'query_type': {'required': True, 'constant': True},
        'expression': {'required': True},
    }

    _attribute_map = {
        'query_type': {'key': 'QueryType', 'type': 'str', 'xml': {'name': 'QueryType'}},
        'expression': {'key': 'Expression', 'type': 'str', 'xml': {'name': 'Expression'}},
        'input_serialization': {'key': 'InputSerialization', 'type': 'QuerySerialization', 'xml': {'name': 'InputSerialization'}},
        'output_serialization': {'key': 'OutputSerialization', 'type': 'QuerySerialization', 'xml': {'name': 'OutputSerialization'}},
    }
    _xml_map = {
        'name': 'QueryRequest'
    }

    query_type = "SQL"

    def __init__(self, *, expression: str, input_serialization=None, output_serialization=None, **kwargs) -> None:
        super(QueryRequest, self).__init__(**kwargs)
        self.expression = expression
        self.input_serialization = input_serialization
        self.output_serialization = output_serialization


class QuerySerialization(Model):
    _validation = {
        'format': {'required': True},
    }

    _attribute_map = {
        'format': {'key': 'Format', 'type': 'QueryFormat', 'xml': {'name': 'Format'}},
    }
    _xml_map = {
    }

    def __init__(self, *, format, **kwargs) -> None:
        super(QuerySerialization, self).__init__(**kwargs)
        self.format = format


class RetentionPolicy(Model):
    _validation = {
        'enabled': {'required': True},
        'days': {'minimum': 1},
    }

    _attribute_map = {
        'enabled': {'key': 'Enabled', 'type': 'bool', 'xml': {'name': 'Enabled'}},
        'days': {'key': 'Days', 'type': 'int', 'xml': {'name': 'Days'}},
    }
    _xml_map = {
    }

    def __init__(self, *, enabled: bool, days: int=None, **kwargs) -> None:
        super(RetentionPolicy, self).__init__(**kwargs)
        self.enabled = enabled
        self.days = days



class StorageError(Model):
    _attribute_map = {
        'message': {'key': 'Message', 'type': 'str', 'xml': {'name': 'Message'}},
    }
    _xml_map = {
    }

    def __init__(self, *, message: str=None, **kwargs) -> None:
        super(StorageError, self).__init__(**kwargs)
        self.message = message


class StorageErrorException(HttpResponseError):
    def __init__(self, response, deserialize, *args):

      model_name = 'StorageError'
      self.error = deserialize(model_name, response)
      if self.error is None:
          self.error = deserialize.dependencies[model_name]()
      super(StorageErrorException, self).__init__(response=response)
