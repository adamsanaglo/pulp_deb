from azure.core.configuration import Configuration
from azure.core.pipeline import policies


class AzureBlobStorageConfiguration(Configuration):
    def __init__(self, url, **kwargs):

        if url is None:
            raise ValueError("Parameter 'url' must not be None.")

        super(AzureBlobStorageConfiguration, self).__init__(**kwargs)
        self._configure(**kwargs)

        self.generate_client_request_id = True

        self.url = url
        self.version = "2019-12-12"

    def _configure(self, **kwargs):
        self.user_agent_policy = kwargs.get('user_agent_policy') or policies.UserAgentPolicy(**kwargs)
        self.headers_policy = kwargs.get('headers_policy') or policies.HeadersPolicy(**kwargs)
        self.proxy_policy = kwargs.get('proxy_policy') or policies.ProxyPolicy(**kwargs)
        self.logging_policy = kwargs.get('logging_policy') or policies.NetworkTraceLoggingPolicy(**kwargs)
        self.retry_policy = kwargs.get('retry_policy') or policies.RetryPolicy(**kwargs)
        self.custom_hook_policy = kwargs.get('custom_hook_policy') or policies.CustomHookPolicy(**kwargs)
        self.redirect_policy = kwargs.get('redirect_policy') or policies.RedirectPolicy(**kwargs)
