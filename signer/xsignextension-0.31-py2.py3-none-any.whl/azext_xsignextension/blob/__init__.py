import os

from typing import Union, Iterable, AnyStr, IO, Any, Dict  # pylint: disable=unused-import
from ._blob_client import BlobClient
from ._download import StorageStreamDownloader
from ._shared.policies import ExponentialRetry, LinearRetry
from ._shared.response_handlers import PartialBatchErrorException
from ._shared.models import(
    LocationMode,
    ResourceTypes,
    AccountSasPermissions,
    StorageErrorCode,
)

from ._models import (
    BlobType,
    BlockState,
    FilteredBlob,
    LeaseProperties,
    ContentSettings,
    CopyProperties,
    BlobBlock,
    ContainerSasPermissions,
    BlobSasPermissions,
    BlobQueryError,
    DelimitedJsonDialect,
    DelimitedTextDialect,
    ObjectReplicationPolicy,
    ObjectReplicationRule
)


def upload_blob_to_url(
        blob_url,  # type: str
        data,  # type: Union[Iterable[AnyStr], IO[AnyStr]]
        credential=None,  # type: Any
        **kwargs):
    # type: (...) -> Dict[str, Any]
    with BlobClient.from_blob_url(blob_url, credential=credential) as client:
        return client.upload_blob(data=data, blob_type=BlobType.BlockBlob, **kwargs)


def _download_to_stream(client, handle, **kwargs):
    stream = client.download_blob(**kwargs)
    stream.readinto(handle)


def download_blob_from_url(
        blob_url,  # type: str
        output,  # type: str
        credential=None,  # type: Any
        **kwargs):
    # type: (...) -> None
    overwrite = kwargs.pop('overwrite', False)
    with BlobClient.from_blob_url(blob_url, credential=credential) as client:
        if hasattr(output, 'write'):
            _download_to_stream(client, output, **kwargs)
        else:
            if not overwrite and os.path.isfile(output):
                raise ValueError("The file '{}' already exists.".format(output))
            with open(output, 'wb') as file_handle:
                _download_to_stream(client, file_handle, **kwargs)


__all__ = [
    'upload_blob_to_url',
    'download_blob_from_url',
    'BlobServiceClient',
    'BlobClient',
    'BlobType',
    'BlobLeaseClient',
    'StorageErrorCode',
    'ExponentialRetry',
    'LinearRetry',
    'LocationMode',
    'BlockState',
    'FilteredBlob',
    'LeaseProperties',
    'ContentSettings',
    'CopyProperties',
    'BlobBlock',
    'ContainerSasPermissions',
    'BlobSasPermissions',
    'ResourceTypes',
    'AccountSasPermissions',
    'StorageStreamDownloader',
    'generate_account_sas',
    'generate_container_sas',
    'generate_blob_sas',
    'PartialBatchErrorException',
    'BlobQueryError',
    'DelimitedJsonDialect',
    'DelimitedTextDialect',
    'BlobQueryReader',
    'ObjectReplicationPolicy',
    'ObjectReplicationRule'
]
