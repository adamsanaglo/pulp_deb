import sys

CONNECTION_TIMEOUT = 20
READ_TIMEOUT = 20

if sys.version_info >= (3, 5):
    READ_TIMEOUT = 80000

STORAGE_OAUTH_SCOPE = "https://storage.azure.com/.default"

SERVICE_HOST_BASE = 'core.windows.net'
