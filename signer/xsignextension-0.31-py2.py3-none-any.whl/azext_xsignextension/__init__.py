from knack.help_files import helps

from azure.cli.core import AzCommandsLoader
from azure.cli.core import get_default_cli as cli

from azext_xsignextension.EsrpSign import EsrpSign
from azext_xsignextension.Helpers import Helpers
from azext_xsignextension.ConfigFile import ConfigFile



def sign_file(file_name, config_file, signed_file_name=None, result_summary=None):

    config = ConfigFile(config_file)
    timeout = config.get_timeout()
    esrp_sign = None


    @Helpers.timeout_decorator(timeout)
    def start_process():
        esrp_sign.sign_file()

        
    try:
        esrp_sign = EsrpSign(file_path=file_name, config=config, signed_file_path=signed_file_name)
        start_process()
        if result_summary:
            Helpers.write_result_json(esrp_final_status=esrp_sign.status, result_summary=result_summary)
        Helpers.exit_program("Exiting...")
        
    except Exception as ex:
        if esrp_sign:
            esrp_sign.status.error_details = str(ex)
            esrp_sign.log_status("SignSubmissionFailed", error=True)   

        if result_summary:
            Helpers.write_result_json(esrp_final_status=esrp_sign.status, result_summary=result_summary)
        Helpers.exit_program(str(ex), status_code=1)
    


helps['xsign sign-file'] = """
    type: command
    short-summary: Used to sign a file through ESRP.
    examples:
        - name: Submit a file to sign and save signed file to a new file.
          text: >
            az xsign --file-name \\Path\\To\\Unsigned\\File --signed-file-name \\Path\\For\\Signed\\File --config-file \\Path\\To\\ConfigJson 
        - name: Submit a file to sign and overwrite with signed version.
          text: >
            az xsign --file-name \\Path\\To\\Unsigned\\File --config-file \\Path\\To\\ConfigJson
        - name: Optional parameters
          text: >
            --result-summary \\Path\\To\\OutputResult (Saves a summary of the file signed.)

"""


class XsignCommandsLoader(AzCommandsLoader):

    def __init__(self, cli_ctx=None):
        from azure.cli.core.commands import CliCommandType
        custom_type = CliCommandType(operations_tmpl='azext_xsignextension#{}')
        super(XsignCommandsLoader, self).__init__(cli_ctx=cli_ctx,
                                                       custom_command_type=custom_type)

    def load_command_table(self, args):
        with self.command_group('xsign') as g:
            g.custom_command('sign-file', 'sign_file')
        return self.command_table

    def load_arguments(self, _):
        pass

COMMAND_LOADER_CLS = XsignCommandsLoader
