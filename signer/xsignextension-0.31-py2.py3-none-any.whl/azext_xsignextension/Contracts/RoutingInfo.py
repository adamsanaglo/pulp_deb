class RoutingInfo():
    def __init__(self, intent: str, contentType: str, contentOrigin: str, productState: str, audience: str):
        self.intent=intent
        self.contentType=contentType
        self.productState=productState
        self.audience=audience


    def reprJSON(self):
        return dict(intent=self.intent, contentType=self.contentType, productState=self.productState) 
