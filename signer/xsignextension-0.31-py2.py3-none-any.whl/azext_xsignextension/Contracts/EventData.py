class Records(object):
    def __init__(self, records):
        self.records=records #record[]

    def reprJSON(self):
        return dict(records=self.records) 


class Record(object):
    def __init__(self, properties, time, level=4):
        self.level = level #LogLevel usually 4
        self.properties = properties #Properties
        self.time = time #DateTimeOffset

    def reprJSON(self):
        return dict(level=self.level.value, properties=self.properties, time=self.time) 


class Properties(object):
    def __init__(self, keywords, provider_name, message):
        self.keywords = keywords #int
        self.provider_name = provider_name #string
        self.message = message #string
    
    def reprJSON(self):
        return dict(Keywords=self.keywords.value, ProviderName=self.provider_name, 
                        Message=self.message)#, EventId=self.event_id)

