from azext_xsignextension.Helpers import Helpers


class StatusModel(object):
    def __init__(self):
        self.status = ""
        self.start_time = ""
        self.end_time = ""
        self.error_details = ""



class CurrentStatus(StatusModel):
    def __init__(self, *args, **kwargs):
        super(CurrentStatus, self).__init__(*args, **kwargs)
        self.isSuccess = ""
        self.operationId = ""
        self.sessionStatus = SessionStatus()
        self.fileUploadStatus = FileUploadStatus()
        self.fileDownloadStatus = FileDownloadStatus()
        self.signFileStatus = SignFileStatus()
        self.esrpAzCliSessionId = ""

    def reprJSON(self):
        return dict(operationId = self.operationId,  processStartTime=self.start_time, processEndTime=self.end_time,
            isSuccess=self.isSuccess, sessionStatus=self.sessionStatus.reprJSON(), fileUploadStatus=self.fileUploadStatus.reprJSON(), signFileStatus=self.signFileStatus.reprJSON(),
            fileDownloadStatus=self.fileDownloadStatus.reprJSON(), errorDetails=self.error_details, esrpAzCliSessionId=self.esrpAzCliSessionId)


class SessionStatus(StatusModel):
    def __init__(self, *args, **kwargs):
        super(SessionStatus, self).__init__(*args, **kwargs)
        self.operation_id = ""

    def reprJSON(self):
        return dict(sessionOperationId = self.operation_id, status=self.status, startTime=self.start_time, 
            endTime=self.end_time, errorDetails=self.error_details)


class FileUploadStatus(StatusModel):
    def __init__(self, *args, **kwargs):
        super(FileUploadStatus, self).__init__(*args, **kwargs)
        self.file_path = ""
        self.blob_url = ""
        self.file_size = ""
        self.hash = ""

    def reprJSON(self):
        return dict(filePath=self.file_path, blobUrl=self.blob_url, fileSize=self.file_size, hash=self.hash,
            status=self.status, startTime=self.start_time, endTime=self.end_time, errorDetails=self.error_details)


class FileDownloadStatus(FileUploadStatus):
    def __init__(self, *args, **kwargs):
        super(FileDownloadStatus, self).__init__(*args, **kwargs)

    def reprJSON(self):
        return dict(filePath=self.file_path, blobUrl=self.blob_url, fileSize=self.file_size, hash=self.hash,
            status=self.status, startTime=self.start_time, endTime=self.end_time, errorDetails=self.error_details)


class SignFileStatus(StatusModel):
    def __init__(self, *args, **kwargs):
        super(SignFileStatus, self).__init__(*args, **kwargs)
        self.file_path = ""
        self.signed_file_path = ""
        self.source_blob_url = ""
        self.destination_blob_url = ""
        self.sign_operations = ""
        self.operation_id = ""
        self.file_size = ""
        self.hash = ""
        self.status = ""

    def reprJSON(self):
        return dict(filePath=self.file_path, signedFilePath=self.signed_file_path, sourceBlobUrl=self.source_blob_url, destinationBlobUrl=self.destination_blob_url, 
            signOperations=self.sign_operations, signOperationId=self.operation_id, fileSize=self.file_size,
            hash=self.hash, signStatus=self.status, startTime=self.start_time, endTime=self.end_time, errorDetails=self.error_details)