from azext_xsignextension.Contracts.SessionRequestMessage import RoutingInfo

from typing import List

class FileLocation(object):
    def __init__(self, _type:str="", uncPath:str="", blobUrl:str=""):
        self.blobUrl=blobUrl
        self.type=_type
        self.uncPath=uncPath

    def reprJSON(self):
        return dict(blobUrl=self.blobUrl, type=self.type, uncPath=self.uncPath)

class DestinationLocation(FileLocation):
    pass

class SourceLocation(FileLocation):
    pass


class Parameter(object):
    def __init__(self, parameterName:str, parameterValue:str):
        self.parameterName=parameterName
        self.parameterValue=parameterValue

    def reprJSON(self):
        return dict(parameterName=self.parameterName, parameterValue=self.parameterValue)


class SigningOperation(object):
    def __init__(self, keycode:str, operationSetCode:str, parameters:List[Parameter], toolName:str, toolVersion:str):
        self.keycode=keycode
        self.operationSetCode=operationSetCode
        self.parameters=parameters
        self.toolName=toolName
        self.toolVersion=toolVersion

    def reprJSON(self):
        return dict(keycode=self.keycode, operationSetCode=self.operationSetCode, parameters=self.parameters, 
            toolName=self.toolName, toolVersion=self.toolVersion)


class DynamicSigningOperation(SigningOperation):
    pass



class SignFileInfo(object):
    def __init__(self, sizeInBytes:int=None, hashType:str=None, destinationLocation:DestinationLocation=None,
        signingOperations:List[SigningOperation]=None, dynamicSigningOperations:List[DynamicSigningOperation]=None,
         name:str=None, hash:str=None,  sourceLocation:SourceLocation=None):

        self.destinationLocation=destinationLocation
        self.signingOperations=signingOperations
        self.dynamicSigningOperations=dynamicSigningOperations
        self.name=name
        self.hash=hash
        self.sourceLocation=sourceLocation
        self.sizeInBytes=sizeInBytes
        self.hashType=hashType

    def reprJSON(self):
        return dict(sizeInBytes=self.sizeInBytes, hashType=self.hashType, destinationLocation=self.destinationLocation,
            signingOperations=self.signingOperations, dynamicSigningOperations=None,
            name=self.name, hash=self.hash,  sourceLocation=self.sourceLocation)



class SignRequestMessage(object):
    def __init__(self, file:SignFileInfo, jwsToken:str, clientId:str, routingInfo:RoutingInfo,
         driEmail:List[str], groupId:str,customerCorrelationId:str, esrpCorrelationId:str, version:str, 
         contextData:dict, requestExpiresAt:str=None):

        self.file=file
        self.jwsToken=jwsToken
        self.clientId=clientId
        self.routingInfo=routingInfo
        self.requestExpiresAt=requestExpiresAt
        self.driEmail=driEmail
        self.groupId=groupId
        self.customerCorrelationId=customerCorrelationId
        self.esrpCorrelationId=esrpCorrelationId
        self.version=version
        self.contextData=contextData

    def reprJSON(self):
        return dict(file=self.file, jwsToken=self.jwsToken, clientId=self.clientId, routingInfo=self.routingInfo,
            requestExpiresAt=self.requestExpiresAt, driEmail=self.driEmail, groupId=self.groupId,
            customerCorrelationId=self.customerCorrelationId, esrpCorrelationId=self.esrpCorrelationId,
            version=self.version, contextData=self.contextData)

    
