from azext_xsignextension.Contracts.RoutingInfo import *

class SessionRequestMessage():
    def __init__(self, expiresAfter: str, routingInfo: RoutingInfo, partitionCount: str):
        # expiresAfter: Represents when the storage sas url will be expired.
        self.expiresAfter=expiresAfter # Timespan

        self.routingInfo=routingInfo # RoutingInfo

        # partitionCount: Specify how many partitions needs to be created.
        self.partitionCount=partitionCount # this is ignored by gateway

        # isProvisionStorage:  Can provision the storage or not
        self.isProvisionStorage = True # bool

        # commandName: client execution command
        self.commandName = "sign" # TODO: This may dynamically have to be changed to digest later

    def reprJSON(self):
        return dict(expiresAfter=self.expiresAfter, routingInfo=self.routingInfo, 
            partitionCount=self.partitionCount, isProvisionStorage=self.isProvisionStorage, 
            commandName=self.commandName)


