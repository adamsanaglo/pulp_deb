import enum

class Keywords(enum.Enum):

    # Attached to all events are not considered sensitive.
    # Keywords.General is mutually exclusive with "Keywords.Sensitive" and can not be combined.
    General = 1

    # Attached to all events that are real-time in nature.
    # "Keywords.Realtime"  can be combined with both "Keywords.General" and "Keywords.Sensitive"
    Realtime = 2

    # Attached to all events containing sensitive information.
    # "Keywords.Sensitive" is mutually exclusive with "Keywords.General" and can not be combined.
    Sensitive = 4

    # Attached to all events containing diagnostic information.
    Diagnostic = 8
    

class LogEvent(object):
    def __init__(self, client_id, event, details, level):
        self.client_id=client_id
        self.event=event
        self.details=details
        self.level=level

class LogLevel(enum.Enum):
            
    Critical: int = 1
    Error: int = 2
    Warning: int = 3
    Informational: int = 4
    Verbose: int = 5