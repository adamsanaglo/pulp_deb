import json
import platform

from datetime import datetime
from os import getenv

from azext_xsignextension.eventhub.EventHubClient import EventData, EventHubProducerClient
from azext_xsignextension.Contracts.EventData import * # pylint: disable=unused-wildcard-import
from azext_xsignextension.Contracts.LogData import * # pylint: disable=unused-wildcard-import
from azext_xsignextension.Contracts.Status import CurrentStatus
from azext_xsignextension.Helpers import Helpers


class EsrpLogger(object):
    def __init__(self, connection_string, client_id=None):
        self.connection_string=connection_string
        self.producer = EventHubProducerClient.from_connection_string(conn_str=connection_string)
        self.client_id = client_id
        self.informational(event="LoggingInitialized")


    def generate_telemetry_message(self, event_name, level, status):
        telemetry_msg = {}
        telemetry_msg["ver"] = getenv('BUILD_BUILDNUMBER', "")
        telemetry_msg["name"] = event_name
        telemetry_msg["time"] = Helpers.get_iso_time()
        telemetry_msg["os"] = platform.system()
        telemetry_msg["osVer"] = platform.release()
        telemetry_msg["appId"] = "Ms.Ess.Sign.Client.AzCli"
        telemetry_msg["appVer"] = getenv('BUILD_BUILDNUMBER', "")
        telemetry_msg["clientId"] = self.client_id

        # add status
        if type(status) is str:
            telemetry_msg["Details"] = status
        else:
            status_dict =  json.loads(json.dumps(status.reprJSON(), cls=Helpers.ComplexEncoder))
            telemetry_msg = {**telemetry_msg, **status_dict}

        telemetry_msg["cV"] = ""
        telemetry_msg["ext.ssl.level"] = level.value
        telemetry_msg["ext.cloud.name"] = event_name

        telemetry_json = json.dumps(telemetry_msg)
        return telemetry_json


    def informational(self, event, details=""):
        level = LogLevel.Informational
        log_event = LogEvent(client_id=self.client_id, event=event, details=details, level=level)
        event_to_log = self.create_event(log_event)
        self.send_event(event_to_log)


    def error(self, event, details=""):
        level = LogLevel.Critical
        log_event = LogEvent(client_id=self.client_id, event=event, details=details, level=level)
        event_to_log = self.create_event(log_event)
        self.send_event(event_to_log)


    def create_event(self, log_event):
        keyword=Keywords.Realtime
        provider_name="Ms.Ess.Sign.Client.AzCli." + log_event.event

        # generate message that will be shown
        message_to_log = self.generate_telemetry_message(level=log_event.level, event_name=provider_name, status=log_event.details)

        # create telemetry metadata specific to ESRP's Ms.Telemetry
        property_to_log = Properties(keywords=keyword,provider_name=provider_name,message=message_to_log)#, event_id=event_id)
        record = Record(level=log_event.level,properties=property_to_log, time=Helpers.get_iso_time())
        records = Records(records=[record])

        # generate json
        event_json = json.dumps(records.reprJSON(), cls=Helpers.ComplexEncoder)
        return event_json


    def send_event(self, event_json):
        event_data_batch = self.producer.create_batch()
        event_data_batch.add(EventData(event_json))
        self.producer.send_batch(event_data_batch)