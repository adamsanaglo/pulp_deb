import json
import random
from base64 import b64encode
from collections import namedtuple
from os import path
from uuid import uuid4
from urllib.parse import unquote
from datetime import timedelta
import time

from azext_xsignextension.Contracts.SignRequestMessage import * # pylint: disable=unused-wildcard-import
from azext_xsignextension.Contracts.SessionRequestMessage import *
from azext_xsignextension.Contracts.Status import CurrentStatus
from azext_xsignextension.EsrpLogger import * # pylint: disable=unused-wildcard-import
from azext_xsignextension.EsrpGatewayClient import * # pylint: disable=unused-wildcard-import
from azext_xsignextension.Helpers import Helpers

class EsrpSign(object):
    def __init__(self, config, file_path, signed_file_path=None):
        self.file_path = file_path
        self.file_name = path.basename(file_path)
        self.config = config.get_config_properties()
        self.client_id = self.config.clientId
        self.request_signing_cert_subject = self.config.requestSigningCert.subject
        self.request_signing_cert_vault_name = self.config.requestSigningCert.vaultName
        self.gateway_api = self.config.gatewayApi

        self.signed_file_path = signed_file_path or self.file_path
        self.bearer_token = self.get_bearer_token()
        self.status = CurrentStatus()
        self.status.esrpAzCliSessionId = str(uuid4())
        self.file_size = path.getsize(self.file_path)
        self.hash = b64encode(Helpers.hash_file(self.file_path)).decode()
        self.routing_info = None
        self.operation_id = None
        self.logger = None



    def log_status(self, event, error=False):
        if self.logger is None:
            return
        if error:
            self.logger.error(event=event, details=self.status)
        else:
            self.logger.informational(event=event, details=self.status)


    def get_bearer_token(self):
        # Get Auth Token
        bearer_token = Helpers.get_auth_bearer_token(self.gateway_api)
        if bearer_token is None:
            raise Exception("\nCould not load bearer token. Please verify that you have logged in.")

        return bearer_token


    def create_session(self):
        # Update status
        Helpers.print_to_console("Preparing to create an ESRP session.")
        self.status.sessionStatus.start_time = Helpers.get_iso_time()
        self.status.sessionStatus.status = "inprogress"

        # Create Session Request Message
        expires_after = str(timedelta(hours=6))
        if self.routing_info is None:
            routing_info = RoutingInfo(intent="",contentType="", contentOrigin="",productState="",audience="")
        session_request = SessionRequestMessage(expiresAfter=expires_after,routingInfo=routing_info,partitionCount=2)
        payload = json.dumps(session_request.reprJSON(), cls=Helpers.ComplexEncoder)

        # Create session
        response = self.esrp_client.create_session(self.get_access_token(), payload)

        # Update status if error
        is_success = Helpers.parse_response(response)
        if not is_success:
            details = "Could not create an ESRP session. "+ str(response.headers)
            self.status.sessionStatus.error_details = details
            self.status.sessionStatus.status = "failed"
            raise Exception(details)

        # Parse session details
        session_configs = json.loads(response.text, object_hook=lambda d:  namedtuple('session_configs', d.keys())(*d.values()))

        # Update status
        self.setup_telemetry_client(session_configs)
        self.status.sessionStatus.end_time = Helpers.get_iso_time()
        self.status.sessionStatus.status = "pass"
        self.status.sessionStatus.operation_id = session_configs.operationId
        self.log_status("SessionCreationCompleted")

        return session_configs


    def setup_telemetry_client(self, session_configs):
        connection_string = random.choice(session_configs.clientConfig.eventHubTelemetryConnectionShard) \
            .connectionString
        self.logger = EsrpLogger(connection_string, self.client_id)


    def download_file(self, blob_url, file_name, destination_file_hash):
        # Update and send status
        self.status.fileDownloadStatus.start_time = Helpers.get_iso_time()
        self.status.fileDownloadStatus.status = "inprogress"
        self.status.fileDownloadStatus.blob_url = blob_url
        self.status.fileDownloadStatus.file_path = self.signed_file_path
        self.status.fileDownloadStatus.file_size = self.file_size
        self.log_status("FileDownloadStarted")

        # Download file
        try:
            Helpers.download_blob(file_name=file_name, blob_url=blob_url, destination_hash=destination_file_hash)
            details = "File downloaded successfully from blob: " + blob_url
            self.status.fileDownloadStatus.status = "pass"
            self.status.fileDownloadStatus.end_time = Helpers.get_iso_time()
            self.status.processEndTime = Helpers.get_iso_time()
            self.status.isSuccess = True
            self.status.fileDownloadStatus.hash = b64encode(Helpers.hash_file(self.signed_file_path)).decode()
            self.log_status("FileDownloadCompleted")
        except Exception as err:
            details = "FailCanRetry: File could not be downloaded from "+blob_url + " Error: " + str(err)
            self.status.fileDownloadStatus.status = "fail"
            self.status.fileDownloadStatus.end_time = Helpers.get_iso_time()
            self.status.isSuccess = False
            self.status.fileDownloadStatus.error_details = details
            self.log_status("FileDownloadFailed", error=True)
            raise


    def upload_file(self, blob_url, file_name):
        # Update and send status
        self.status.fileUploadStatus.start_time = Helpers.get_iso_time()
        self.status.fileUploadStatus.status = "inprogress"
        self.status.fileUploadStatus.blob_url = blob_url
        self.status.fileUploadStatus.file_path = self.file_path
        self.status.fileUploadStatus.file_size = self.file_size
        self.status.fileUploadStatus.hash = self.hash
        self.log_status("FileUploadStarted")

        # Upload file
        try:
            Helpers.upload_blob(file_name=self.file_path, blob_url=blob_url)
            details = "File uploaded successfully to blob: " + blob_url
            self.status.fileUploadStatus.status = "pass"
            self.status.fileUploadStatus.end_time = Helpers.get_iso_time()
            self.log_status("FileUploadCompleted")
        except Exception as err:
            details = "File could not be uploaded to " + blob_url + " Error: " + str(err)
            self.status.fileUploadStatus.status = "fail"
            self.status.fileUploadStatus.end_time = Helpers.get_iso_time()
            self.status.fileUploadStatus.error_details = details
            self.log_status("FileUploadFailed", error=True)
            raise

    def generate_sign_request_message(self, source_blob_url, destination_blob_url):
        # Prepare signInfo details
        source_blob_url = source_blob_url
        destination_blob_url = destination_blob_url
        sign_file_info = SignFileInfo()
        sign_file_info.sourceLocation = SourceLocation('azureBlob', blobUrl=source_blob_url)
        sign_file_info.destinationLocation = DestinationLocation('azureBlob', blobUrl=destination_blob_url)
        sign_file_info.hash=self.hash
        sign_file_info.hashType=self.config.hashType
        sign_file_info.sizeInBytes=self.file_size
        sign_file_info.name=self.file_name

        # Prepare signing operations - only static embedded for now
        sign_ops=[]
        for sign_op in self.config.signingOperations:
            params=[]
            for param in sign_op.parameters:
                params.append(Parameter(parameterName=param.parameterName, parameterValue=param.parameterValue))

            sign_ops.append(
                SigningOperation(
                    keycode=sign_op.keyCode,
                    operationSetCode=sign_op.operationSetCode,
                    parameters=params if len(params)>0 else '',
                    toolName=sign_op.toolName,
                    toolVersion=sign_op.toolVersion
                )
            )
        sign_file_info.signingOperations=sign_ops

        signRequestMsg = SignRequestMessage(
            clientId=self.config.clientId,
            driEmail=self.config.driEmail,
            routingInfo=RoutingInfo(intent="",contentType="",contentOrigin="",productState="",audience=""),
            groupId=None, #groupId=storageResultMessage["groupId"], # TODO: Find when this is used
            customerCorrelationId="",#storage_result_message["customerCorrelationId"],
            version="", #TODO: Figure out source of this info
            contextData="", # TODO: Figure out source of this info,
            jwsToken=None,
            esrpCorrelationId=None,
            file=sign_file_info)

        self.status.signFileStatus.sign_operations = signRequestMsg
        return signRequestMsg

    def get_access_token(self):
        isValid = Helpers.check_auth_bearer_token_validity(self.bearer_token)
        if not isValid:
            self.bearer_token = self.get_bearer_token()

        return self.bearer_token["accessToken"]


    def prepare_sign_request_msg(self, source_blob_url, destination_blob_url):
        # Generate Sign Request Message and jws token
        self.log_status("PreparingSignRequestMessage")
        signRequestMsg = json.loads(Helpers.toJson(self.generate_sign_request_message(source_blob_url=source_blob_url, destination_blob_url=destination_blob_url)))
        jwsToken = Helpers.generate_jws_token(self.request_signing_cert_subject, self.request_signing_cert_vault_name, signRequestMsg)
        signRequestMsg["jwsToken"]=str(jwsToken, 'utf-8')
        signRequestMsgJson =  "["+Helpers.toJson(signRequestMsg)+"]" # gateway receives a list of sign request messages
        return signRequestMsgJson

    def submit_file_to_sign(self, signRequestJson):
        # Update status
        self.status.signFileStatus.start_time = Helpers.get_iso_time()
        self.status.signFileStatus.file_name = self.file_path
        self.status.signFileStatus.signed_file_path = self.signed_file_path
        self.status.signFileStatus.source_blob_url = self.status.fileUploadStatus.blob_url
        self.status.signFileStatus.hash = self.hash
        self.log_status("SignSubmissionStarted")

        # Submit file to sign
        response = self.esrp_client.submit_to_sign_file(signRequestJson, self.get_access_token())
        if not response:
            # Hotfix: 429 retry
            if response is not None:
                while response.status_code == 429:
                    retry_after = response.headers.get("Retry-After", 10)
                    if retry_after:
                        Helpers.print_to_console("429: Retrying after "+str(retry_after)+" seconds...")
                        time.sleep(int(retry_after))
                    response = self.esrp_client.submit_to_sign_file(signRequestJson, self.get_access_token())

        # Update status
        if not response:
            self.status.signFileStatus.error_details = "Failed to submit file to sign. Error: {status_code} {reason}".format(status_code=str(getattr(response, "status_code", "")), reason=getattr(response, "reason", ""))
            self.status.signFileStatus.end_time = Helpers.get_iso_time()
            self.status.signFileStatus.sign_status = "failed"
            self.log_status(event="SignSubmissionFailed", error=True)
            raise Exception(self.status.signFileStatus.error_details)


        # Retrieving operation id & updating status
        operation_id = response.json()[0]["operationId"]
        self.status.operationId = operation_id
        self.status.signFileStatus.operation_id = operation_id
        self.status.signFileStatus.sign_status = "inprogress"
        self.log_status(event="SignSubmissionCompleted")

        return operation_id


    def query_sign_status(self):
        self.status.signFileStatus.status = "inProgress"
        self.status.signFileStatus.start_time = Helpers.get_iso_time()
        self.status.signFileStatus.file_name = self.file_name
        self.status.signFileStatus.file_size = self.file_name
        self.status.signFileStatus.hash = self.hash
        self.status.signFileStatus.operation_id = self.operation_id
        response = self.esrp_client.query_sign_status(operation_id=self.operation_id,
            bearer_auth=self.get_access_token())

        if response is None:
            self.status.signFileStatus.status = "failCanRetry" # currently mostly due to timeout
            self.status.signFileStatus.end_time = Helpers.get_iso_time()
            self.status.signFileStatus.details = "Failed to get response from gateway within specified time."
            self.log_status(event="FileSigningFailed", error=True)
            raise Exception("Signing failed. Please check your configuration and try again.")

        signFileResult = response.json()
        self.status.signFileStatus.status = signFileResult['status']
        self.status.signFileStatus.end_time = Helpers.get_iso_time()

        if self.status.signFileStatus.status == "pass":
            Helpers.print_to_console("Pass: File successfully signed.")
            self.log_status("FileSigningCompleted")
            return response

        elif self.status.signFileStatus.status == "failCanRetry":
            self.log_status("FileSigningFailed")
            self.status.signFileStatus.error_details = "TransientError: " + response.text
            raise Exception("FailCanRetry: Signing failed. Error: "+ response.text)

        elif self.status.signFileStatus.status == "failDoNotRetry":
            self.log_status("FileSigningFailed", error=True)
            self.status.signFileStatus.error_details = "Error: " + response.text
            raise Exception("FailDoNotRetry: Signing failed. Error: "+ response.text)

        elif self.status.signFileStatus.status == "pendingAnalysis":
            self.log_status("PendingAnalysis", error=True)
            self.status.signFileStatus.error_details = "Error: " + response.text
            raise Exception("PendingAnalysis: A file has been flagged as potential malware. \
                Please allow 2 business days for inspection. File ICM ticket to ESRP Scan team for \
                expedited approval.")

        elif self.status.signFileStatus.status == "inProgress":
            self.log_status("InProgress", error=True)
            self.status.signFileStatus.error_details = "Error: Timed out. Increase timeout."
            raise Exception(self.status.signFileStatus.error_details)


    def sign_file(self):
        Helpers.print_to_console("AzCli xSign Id: " + self.status.esrpAzCliSessionId)

        # Setup up esrp gateway client
        self.esrp_client = EsrpGatewayClient(gateway_api=self.gateway_api, client_id=self.client_id)

        # Create a session - session initializes telemetry client
        session_configs = self.create_session()
        Helpers.print_to_console("Session RequestId: " + session_configs.operationId)

        # Parse out blob source and destination locations
        source_blob_url = Helpers.generate_blob_url_with_extension(session_configs.storageResult.storageShards[0].shardLocation.bloburl, self.file_name)
        destination_blob_url = Helpers.generate_blob_url_with_extension(session_configs.storageResult.storageShards[1].shardLocation.bloburl, self.file_name)

        Helpers.print_to_console("Uploading file to blob: " + source_blob_url)
        self.upload_file(blob_url=source_blob_url, file_name=self.file_name)
        signRequestJson = self.prepare_sign_request_msg(source_blob_url=source_blob_url, destination_blob_url=destination_blob_url)

        # Submitting file to sign
        Helpers.print_to_console("Submitting file to sign...")
        self.operation_id = self.submit_file_to_sign(signRequestJson=signRequestJson)

        Helpers.print_to_console("ESRP Sign OperationId: "+self.operation_id)

        # Querying for status
        Helpers.print_to_console("Querying ESRP status...")
        response = self.query_sign_status()
        destination_blob_url_from_response = response.json()["destinationLocation"]["bloburl"]
        destination_file_hash = response.json()["destinationFileHash"]
        # Download from blob 
        Helpers.print_to_console("Downloading signed file from blob: "+destination_blob_url_from_response)
        self.download_file(blob_url=destination_blob_url_from_response, file_name=self.signed_file_path, destination_file_hash=destination_file_hash) 
        Helpers.print_to_console("Signed file downloaded to: "+self.signed_file_path)

