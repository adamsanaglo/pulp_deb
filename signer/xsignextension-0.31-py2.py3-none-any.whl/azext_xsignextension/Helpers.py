import errno
import functools
import hashlib
import json
import pathlib
import re
import uuid
import sys

from azure.cli.core import get_default_cli
from azure.cli.core import AzCommandsLoader
from azure.cli.command_modules.profile.custom import get_access_token
from azure.common.credentials import get_azure_cli_credentials
from azure.keyvault.key_vault_client import KeyVaultClient
from base64 import urlsafe_b64encode, b64encode
from binascii import hexlify
from collections import OrderedDict
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse
from threading import Thread


from azext_xsignextension.blob import BlobClient
from azext_xsignextension._version import VERSION

class Helpers:
    @staticmethod
    def print_to_console(message, error=False):
        if error:
            print(Helpers.get_iso_time()+' '+message, file=sys.stderr)
        else:
            print(Helpers.get_iso_time()+' '+message)

    @staticmethod
    def generate_jws_token(subject, vault_name, payload):
        # get credentials
        Helpers.print_to_console("Retrieving certificate from "+vault_name+" to sign request...")
        credentials, subscription_id, tenant_id = get_azure_cli_credentials(resource='https://vault.azure.net', with_tenant=True)

        # Retrieve certificate to retrieve reference to private key
        vault_url = 'https://{vault_name}.vault.azure.net/'.format(vault_name=vault_name)
        cert_client = KeyVaultClient(credentials)
        cert = cert_client.get_certificate(vault_url, subject, '')
        secret_id = cert.sid
        cert_cer = cert.cer
        parsed = urlparse(secret_id).path.split('/')[2:]
        secret_key_name = parsed[0]
        secret_key_version = parsed[1]

        # Get chain and thumbprint for headers
        chain = Helpers.base64encode_Url(cert_cer).decode()
        thumbprint = hexlify(cert.x509_thumbprint).decode()

        algorithm = "RS256"
        header_type = "JWT"

        # get expired time (6 hours from now) - in .Net ticks (gateway only understands .Net ticks)
        ticks = Helpers.get_datetimeoffset(hours_offset=6)

        header = { "typ": header_type,
                    "alg": algorithm,
                    "crit": ["exp", "x5t"],
                    "exp": ticks,
                    "x5c": chain,
                    "x5t": thumbprint}

        json_header = json.dumps(header, separators=(",", ":")).encode('utf-8')
        json_payload = json.dumps(payload, separators=(",", ":")).encode("utf-8") 

        segments = []
        segments.append(Helpers.base64encode_Url(json_header))
        segments.append(Helpers.base64encode_Url(json_payload))

        signing_input = hashlib.sha256(b".".join(segments)).digest()
        Helpers.print_to_console("Preparing to sign request in akv...")
        signature = cert_client.sign(vault_url, secret_key_name, secret_key_version, 'PS256', signing_input).result
        segments.append(Helpers.base64encode_Url(signature))

        return(b".".join(segments))


    @staticmethod
    def get_iso_time():
        return (datetime.utcnow().isoformat()+'Z')
        

    @staticmethod
    def generate_blob_url_with_extension(blob_url, file_name):
        # Create new blob url to have extension in blob url
        match = re.search((r"http(s)?://(?P<account_name>.*?)\.blob\.(?P<endpoint_suffix>.*?)/(?P<container_name>.*?)/"
                        r"(?P<blob_name>.*?)\?(?P<sas_token>.*)"), blob_url)

        # Generate unique file name with extension(s)
        extensions = pathlib.Path(file_name).suffixes # getting all extensions in cases like .tar.gz
        file_name = str(uuid.uuid4()) + ''.join(extensions) 

        account_name = match.group('account_name')
        endpoint_suffix = match.group('endpoint_suffix')
        container_name = match.group('container_name')
        blob_name = match.group('blob_name') + '/' + file_name
        sas_token = match.group('sas_token')

        blob_url = "https://{account_name}.blob.{endpoint_suffix}/{container_name}/{blob_name}?{sas_token}".format(account_name=account_name,endpoint_suffix=endpoint_suffix, container_name=container_name, blob_name=blob_name, sas_token=sas_token)

        return blob_url


    @staticmethod
    def parse_response(response):
        success_codes = [200, 201, 202]
        if response is None:
            return False
        if response.status_code in success_codes:
            return True
        return False


    @staticmethod
    def exit_program(details, status_code=0):
        if status_code == 1:
            Helpers.print_to_console(details + "\nexit code: 1", True)
            sys.exit(1)
        else:
            Helpers.print_to_console(details + "\nexit code: 0")
            sys.exit(0)


    @staticmethod
    def get_auth_bearer_token(gatewayApi):
        token = Helpers.get_access_token_from_cli(resource=gatewayApi)
        return token


    @staticmethod
    def check_auth_bearer_token_validity(token):
        expires_on = token["expiresOn"]
        dt_expires_on = datetime.strptime(expires_on, '%Y-%m-%d %H:%M:%S.%f')
        if datetime.now() > dt_expires_on:
            return False
        else:
            return True


    @staticmethod
    def print_progress_bar(response):
        iteration = response.context.get("upload_stream_current") or response.context.get("download_stream_current")
        total = response.context.get("data_stream_total")

        if iteration is None or total is None:
            return

        decimals = 1
        length = 100

        percent = ("{0:." + str(decimals) + "f}").format(100 * (int(iteration) / float(total)))
        filledLength = int(length * iteration // total)

        try:
            bar = "█" * filledLength + "-" * (length - filledLength)
            print('\n |%s| %s%% ' % (bar, percent), end='\n')
        except UnicodeEncodeError:
            bar = "#" * filledLength + "-" * (length - filledLength)
            print('\n |%s| %s%% ' % (bar, percent), end='\n')
        
        # Print New Line on Complete
        if iteration == total: 
            print()

    @staticmethod
    def base64encode_Url(unencoded):
        return urlsafe_b64encode(unencoded).replace(b'=',b'')

    @staticmethod
    def get_access_token_from_cli(resource=None):
        cmd = AzCommandsLoader(cli_ctx=get_default_cli())
        token = get_access_token(cmd, resource=resource)
        return token

    @staticmethod
    class ComplexEncoder(json.JSONEncoder):
        def default(self, obj): # pylint: disable=method-hidden
            if hasattr(obj,'reprJSON'):
                return obj.reprJSON()
            else:
                return json.JSONEncoder.default(self, obj)

    @staticmethod
    def toJson(obj):
        return json.dumps(obj, default=lambda x: getattr(x, '__dict__', str(x)))

    @staticmethod
    def hash_file(file_name, algorithm='sha256'):
        BUF_SIZE = 65536  # read in 64kb chunks
        hasher = hashlib.sha256()

        with open(file_name, 'rb') as f:
            while True:
                data = f.read(BUF_SIZE)
                if not data:
                    break
                hasher.update(data)
        return hasher.digest()

    @staticmethod
    def get_datetimeoffset(hours_offset=0, minutes_offset=0, seconds_offset=0):
        # .Net ticks (gateway only understands .Net ticks)
        return (10**7 * ((datetime.utcnow() - datetime(1,1,1) + timedelta(hours=hours_offset, minutes=minutes_offset, seconds=seconds_offset)).total_seconds()))


    @staticmethod
    def upload_blob(file_name, blob_url):
        blob_client = BlobClient.from_blob_url(blob_url)
        with open(file_name, 'rb') as stream:
            blob = blob_client.upload_blob(stream, raw_response_hook=Helpers.print_progress_bar)
        return blob

    @staticmethod
    def check_hash_match(file_name, gateway_hash):
        hash =  str(b64encode(Helpers.hash_file(file_name)), encoding='utf-8')
        if hash == gateway_hash:
            return True
        else:
            return False


    @staticmethod
    def download_blob(file_name, blob_url, destination_hash, retries=3):
        blob_client = BlobClient.from_blob_url(blob_url)
        for i in range(retries):
            with open(file_name, 'wb') as f:
                blob_client.download_blob(raw_response_hook=Helpers.print_progress_bar).readinto(f)
            
            # check hash
            if Helpers.check_hash_match(file_name, destination_hash):
                return True
            else:
                Helpers.print_to_console("Hash mismatch: Hash of downloaded file does not match given hash. Retrying...")
        raise Exception("Hash Mismatch: Hash of file saved to "+file_name+" ["+hash+"]"+" does not match hash sent from gateway: ["+destination_hash+"]")


    @staticmethod
    def utc_from_timestamp(timestamp):
        return datetime.datetime.fromtimestamp(timestamp, tz=timezone.utc)

    
    @staticmethod
    def write_result_json(esrp_final_status, result_summary):
    
        output_data = OrderedDict()
        output_data["AzCliVersion"] = VERSION
        output_data["AzCliSessionId"] = esrp_final_status.esrpAzCliSessionId
        output_data["ESRPOperationId"] = esrp_final_status.operationId

        output_data["sourceFileDetails"] = {
            "sourceFilePath" : esrp_final_status.fileUploadStatus.file_path,
            "sourceFileSize" : esrp_final_status.fileUploadStatus.file_size,
            "sourceFileHash" : esrp_final_status.fileUploadStatus.hash
        }

        output_data["signedFileDetails"] = {
            "signedFilePath": esrp_final_status.fileDownloadStatus.file_path,
            "signedFileSize": esrp_final_status.fileDownloadStatus.file_size,
            "signedFileHash": esrp_final_status.fileDownloadStatus.hash
        }

        output_data["status"] = esrp_final_status.signFileStatus.status
        output_data["errorDetails"] = esrp_final_status.error_details

        AzCli_Xsign_Output_Data = OrderedDict()
        AzCli_Xsign_Output_Data["AzCliResult"] = output_data

        serialized = json.dumps(AzCli_Xsign_Output_Data, indent=3)

        try:
            with open(result_summary, 'w+') as output_json:
                output_json.write(serialized)
                Helpers.print_to_console("Results summary written to: " + result_summary)            
        except IOError as x:
            Helpers.print_to_console("Error while writing result summary.", error=True)
            if x.errno == errno.EACCES:
                Helpers.print_to_console("Permission denied to write to:  " + result_summary, error=True)
            elif x.errno == errno.EISDIR:
                Helpers.print_to_console("Path is a directory: " + result_summary, error=True)


    @staticmethod
    def timeout_decorator(timeout):
        def deco(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                res = [TimeoutError('Xsign timed out after %s seconds!' % (timeout))]
                def newFunc():
                    try:
                        res[0] = func(*args, **kwargs)
                    except Exception as e:
                        res[0] = e
                t = Thread(target=newFunc)
                t.daemon = True
                try:
                    t.start()
                    t.join(timeout)
                except Exception as je:
                    print("An error occurred starting xsign sign process thread.")
                    raise je
                ret = res[0]
                if isinstance(ret, BaseException):
                    raise ret
                return ret
            return wrapper
        return deco
